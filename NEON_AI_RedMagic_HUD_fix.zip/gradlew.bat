@echo off
setlocal
set GRADLE_VERSION=8.11.1
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed. Use the Linux gradlew script on the cloud builder or install Gradle 8.11.1.
exit /b 1
