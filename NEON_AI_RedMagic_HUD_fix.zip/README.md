# NEON-YOLO — детектор объектов Brawl Stars для NEON AI / REDMAGIC

Проект подготовки собственной YOLO-модели (Ultralytics YOLO11 → ONNX → ONNX Runtime Android).

## Статус (честно)

* **Обученной модели в проекте нет.** Файла `best.onnx` нет и не будет, пока вы не соберёте датасет и не проведёте обучение.
  `export.py` без `weights/best.pt` останавливается и ничего не создаёт.
* Точность, скорость на REDMAGIC 11 Pro и эффект FP16/INT8 **не измерялись** — это нужно сделать после обучения.
* Проверены только синтаксис Python-скриптов и работа `prepare_dataset.py` на временных синтетических данных.
  Обучение, экспорт и Kotlin-код в этом окружении не запускались (нет GPU/ultralytics/Android-сборки) — ожидайте мелких правок при первой сборке.

## Структура

```
neon-ai-vision/
├── data.yaml              # конфигурация классов и путей
├── labels.txt             # 8 классов (порядок = class id)
├── models/neon_yolo11s.yaml   # архитектура (YOLO11, nc=8) — для --scratch
├── common.py              # letterbox/препроцессинг (идентичен Kotlin)
├── extract_frames.py      # нарезка кадров из записи экрана
├── prepare_dataset.py     # валидация разметки + разбиение train/val/test по матчам
├── train.py               # обучение
├── val.py                 # проверка качества (mAP/P/R по классам)
├── export.py              # ONNX FP32 -> FP16 -> (INT8)
├── raw/images, raw/labels # сюда кладёте скриншоты и разметку
├── dataset/               # создаётся prepare_dataset.py
├── weights/ runs/ export/ # результаты (появятся после обучения/экспорта)
├── docs/LABELING_GUIDE.md # инструкция по разметке
└── android/               # Kotlin-код для ONNX Runtime + плавающий HUD
```

## Классы

`0 brawler · 1 enemy · 2 teammate · 3 projectile · 4 obstacle · 5 bush · 6 health_bar · 7 super_indicator`
Правила разметки — `docs/LABELING_GUIDE.md`. Особенно уточните определения `brawler/enemy/teammate` и `super_indicator`.

## Пошаговая инструкция

1. **Окружение** (ПК с NVIDIA GPU рекомендуется):
   `python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`
2. **Сбор данных:** запишите игровые матчи и нарежьте кадры:
   `python extract_frames.py rec_001.mp4 --match-id m001 --every-sec 0.7`
3. **Разметка:** по `docs/LABELING_GUIDE.md` (CVAT / Label Studio / Roboflow, экспорт в YOLO txt) → `raw/images`, `raw/labels`.
4. **Подготовка датасета:** `python prepare_dataset.py --allow-empty --clean`
   — смотрите вывод: ошибки разметки и число экземпляров по классам.
5. **Обучение:** `python train.py --model yolo11s.pt --epochs 150`
   (для сравнения: `--model yolo11n.pt`). Предобученные веса COCO скачиваются при первом запуске (нужен интернет на ПК обучения,
   на телефоне интернет не нужен). Скрипт откажется работать на пустом/очень маленьком датасете.
6. **Проверка:** `python val.py --weights weights/best.pt --split val`, затем один раз на `--split test`.
7. **Экспорт:** `python export.py` → `export/best.onnx`, `export/best_fp16.onnx`, `export/labels.txt`.
   INT8: `python export.py --int8 --calib-dir dataset/images/train`.
8. **Проверьте каждый ONNX-файл**: `python val.py --weights export/best_fp16.onnx --split test`. INT8 часто теряет качество на мелких объектах.
9. **Android:** см. `android/README_ANDROID.md`. Положите выбранный `.onnx` и `labels.txt` в `assets/`, измерьте `inferenceMs` на устройстве.

## Технические замечания

* Вход 640×640, RGB, 0..1, letterbox с серым (114). Выход `[1, 12, 8400]`: `cx, cy, w, h` в пикселях входа + 8 оценок классов (без objectness). NMS делается в Kotlin.
* **FP16:** `export.py` конвертирует веса в float16, вход/выход остаются float32. На CPU-провайдере ONNX Runtime для ARM
  FP16 часто не быстрее FP32; выигрыш возможен на NNAPI/GPU-провайдерах. Выбирайте по замерам на REDMAGIC 11 Pro.
* **INT8:** статическая QDQ-квантизация, качество зависит от калибровочных кадров — используйте разнообразные кадры из train.
* **Мелкие объекты.** Скриншоты широкоформатные: при сжатии в квадрат 640 снаряды и полоски здоровья становятся очень маленькими.
  Если mAP по `projectile`/`health_bar` низкий, обучите и экспортируйте при `imgsz=960` (и поменяйте `inputSize` в Kotlin) либо добавьте тайлинг.
* **Режимы и аугментации:** `fliplr=0.5` включён; если у вас есть асимметричные элементы HUD, которые важны, поставьте `fliplr=0.0` в `train.py`.

## Ограничения использования

Приложение-оверлей, анализирующее live-матчи и подсказывающее положение врагов/снарядов, может нарушать правила Supercell
и привести к блокировке аккаунта. Проект безопаснее использовать для анализа записей и собственных экспериментов.
