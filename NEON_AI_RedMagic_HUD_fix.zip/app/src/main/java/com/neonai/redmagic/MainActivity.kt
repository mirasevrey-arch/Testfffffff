package com.neonai.redmagic

import android.Manifest
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.neonai.vision.BrawlWatcherService
import com.neonai.vision.DetectionHub
import com.neonai.vision.FloatingHudService
import com.neonai.vision.HudSettings
import com.neonai.vision.ModelManager
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Главный экран настройки NEON AI для REDMAGIC 11 Pro (Android 16).
 * Показывает:
 * - что уже подключено и работает (ONNX-модель, захват экрана, HUD);
 * - какие разрешения нужно включить для автозапуска окна при старте Brawl Stars;
 * - быстрые настройки ИИ (Confidence, IoU, FPS, NNAPI) и внешнего вида HUD.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var tvStatusBanner: TextView
    private lateinit var tvPermOverlayStatus: TextView
    private lateinit var tvPermNotifStatus: TextView
    private lateinit var tvPermUsageStatus: TextView
    private lateinit var tvPermCaptureStatus: TextView
    private lateinit var tvModelInfo: TextView
    private lateinit var tvRuntimeInfo: TextView
    private lateinit var tvLiveMetrics: TextView

    private lateinit var swAutoBrawl: Switch
    private lateinit var tvConfValue: TextView
    private lateinit var sbConf: SeekBar
    private lateinit var tvIouValue: TextView
    private lateinit var sbIou: SeekBar
    private lateinit var fpsButtons: Map<Int, Button>
    private lateinit var swNnapi: Switch

    private lateinit var cbBoxes: CheckBox
    private lateinit var cbLabels: CheckBox
    private lateinit var cbConfidence: CheckBox
    private lateinit var cbDebugCoords: CheckBox

    private lateinit var tvAlphaValue: TextView
    private lateinit var sbAlpha: SeekBar
    private lateinit var tvScaleValue: TextView
    private lateinit var sbScale: SeekBar

    private val cyan = Color.rgb(0, 229, 255)
    private val green = Color.rgb(52, 199, 89)
    private val amber = Color.rgb(255, 190, 70)
    private val red = Color.rgb(255, 69, 58)
    private val muted = Color.rgb(160, 177, 199)
    private val cardBg = Color.rgb(13, 22, 40)

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refreshPermissionsUi()
        if (Settings.canDrawOverlays(this)) {
            tvStatusBanner.text = "Разрешение на отображение поверх окон получено"
        } else {
            tvStatusBanner.text = "Разрешение Overlay не выдано пользователем"
        }
    }

    private val usageAccessLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refreshPermissionsUi()
        if (hasUsageStatsPermission()) {
            syncBrawlWatcherService()
            tvStatusBanner.text = "Доступ к статистике запусков включён — HUD откроется при старте Brawl Stars"
        } else {
            tvStatusBanner.text = "Без доступа к статистике запусков автоопределение игры не сработает (можно открыть HUD вручную)"
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        refreshPermissionsUi()
        tvStatusBanner.text = if (granted) {
            "Разрешение на уведомления выдано"
        } else {
            "Уведомления отклонены: статус сервисов в шторке может не отображаться"
        }
    }

    private val captureConsentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, serviceIntent)

            // Показываем HUD сразу после разрешения Screen Capture.
            // Раньше HUD ожидал обнаружения Brawl Stars через UsageStats,
            // поэтому на устройствах, где событие запуска игры не приходило,
            // пользователь видел активный захват, но не видел само окно HUD.
            if (Settings.canDrawOverlays(this)) {
                startHudServices()
                tvStatusBanner.text = "Захват экрана запущен — HUD открыт"
            } else {
                tvStatusBanner.text = "Захват экрана запущен. Разрешите отображение поверх окон, чтобы увидеть HUD."
                requestOverlayPermission()
            }
        } else {
            DetectionHub.setCaptureStatus(
                DetectionHub.CaptureStatus.STOPPED,
                "Разрешение на захват экрана отклонено"
            )
            tvStatusBanner.text = "Разрешение на захват экрана не выдано"
        }
        refreshPermissionsUi()
    }

    private val modelPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) {
            tvStatusBanner.text = "Выбор файла модели отменён"
            return@registerForActivityResult
        }
        val importRes = ModelManager.importModelFromUri(this, uri)
        importRes.onSuccess { resolved ->
            syncModelStatusToHub()
            if (DetectionHub.captureStatus.value == DetectionHub.CaptureStatus.ACTIVE) {
                startService(Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_RELOAD_MODEL
                })
            }
            tvStatusBanner.text = "Модель загружена: ${resolved.displayName}"
            Toast.makeText(this, "ONNX-модель сохранена: ${resolved.displayName}", Toast.LENGTH_SHORT).show()
        }.onFailure { err ->
            tvStatusBanner.text = "Ошибка импорта модели: ${err.message}"
            Toast.makeText(this, "Ошибка: ${err.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        HudSettings.init(this)
        syncModelStatusToHub()
        buildUi()
        bindSettingsToUi()
        observeHub()
        syncBrawlWatcherService()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionsUi()
        syncModelStatusToHub()
        syncBrawlWatcherService()
    }

    private fun syncBrawlWatcherService() {
        val cfg = HudSettings.config.value
        if (cfg.autoLaunchOnBrawlStars && hasUsageStatsPermission() && Settings.canDrawOverlays(this)) {
            ContextCompat.startForegroundService(this, Intent(this, BrawlWatcherService::class.java))
        }
    }

    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun syncModelStatusToHub() {
        val resolved = ModelManager.resolveActiveModel(this)
        if (resolved == null) {
            DetectionHub.setModelState(
                DetectionHub.ModelState(
                    loaded = false,
                    modelName = null,
                    runtimeProvider = "—",
                    statusText = ModelManager.MISSING_MODEL_MESSAGE,
                )
            )
        } else if (!DetectionHub.modelState.value.loaded || DetectionHub.modelState.value.modelName != resolved.displayName) {
            DetectionHub.setModelState(
                DetectionHub.ModelState(
                    loaded = true,
                    modelName = resolved.displayName,
                    runtimeProvider = if (HudSettings.config.value.useNnapi) "NNAPI (ожидает старт)" else "CPU",
                    statusText = "Подключена ONNX-модель: ${resolved.displayName}",
                )
            )
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(28, 24, 28, 24)
        background = GradientDrawable().apply {
            setColor(cardBg)
            cornerRadius = 24f
            setStroke(2, Color.rgb(24, 48, 82))
        }
    }

    private fun sectionTitle(title: String): TextView = TextView(this).apply {
        text = title
        textSize = 15f
        setTextColor(cyan)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 0, 0, 12)
    }

    private fun styledButton(label: String, accent: Boolean = false, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            setTextColor(if (accent) Color.rgb(5, 14, 26) else Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(if (accent) cyan else Color.rgb(22, 42, 70))
                cornerRadius = 18f
                if (!accent) setStroke(2, Color.rgb(0, 130, 170))
            }
            setOnClickListener { onClick() }
        }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(8, 13, 25))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 48)
        }

        val headerTitle = TextView(this).apply {
            text = "NEON AI • BRAWL STARS + ONNX"
            textSize = 22f
            setTextColor(cyan)
            setTypeface(typeface, Typeface.BOLD)
        }
        val subTitle = TextView(this).apply {
            text = "Android 16 • Авто-HUD при запуске игры и ONNX Runtime"
            textSize = 13f
            setTextColor(muted)
            setPadding(0, 4, 0, 16)
        }
        tvStatusBanner = TextView(this).apply {
            text = "Готово: ONNX-модель подключена, можно включить автозапуск с Brawl Stars или открыть HUD"
            textSize = 13.5f
            setTextColor(Color.WHITE)
            setPadding(20, 16, 20, 16)
            background = GradientDrawable().apply {
                setColor(Color.rgb(16, 32, 56))
                cornerRadius = 16f
                setStroke(2, cyan)
            }
        }
        root.addView(headerTitle)
        root.addView(subTitle)
        root.addView(tvStatusBanner, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 20 })

        val permCard = card()
        permCard.addView(sectionTitle("1. ЧТО ВКЛЮЧИТЬ (РАЗРЕШЕНИЯ И АВТОЗАПУСК)"))

        val quickGuide = TextView(this).apply {
            text = """
                Как это работает:
                • Включите «Поверх других окон» и «Доступ к статистике запусков», чтобы окно HUD с настройками ИИ открывалось само при запуске Brawl Stars.
                • «Screen Capture» нужен только для анализа кадров экрана в реальном времени.
                • Встроенная ONNX-модель уже добавлена в проект; при необходимости замените её своим .onnx файлом ниже.
            """.trimIndent()
            textSize = 12f
            setTextColor(muted)
            setPadding(0, 0, 0, 12)
        }
        permCard.addView(quickGuide)

        swAutoBrawl = Switch(this).apply {
            text = "Автоматически открывать окно HUD при старте Brawl Stars"
            textSize = 13.5f
            setTextColor(Color.WHITE)
            setPadding(0, 4, 0, 12)
            setOnCheckedChangeListener { _, isChecked ->
                HudSettings.update(this@MainActivity) { it.copy(autoLaunchOnBrawlStars = isChecked) }
                if (isChecked) {
                    if (!hasUsageStatsPermission()) {
                        tvStatusBanner.text = "Включите «Доступ к статистике запусков», чтобы приложение видело запуск Brawl Stars"
                    } else {
                        syncBrawlWatcherService()
                        tvStatusBanner.text = "Автозапуск с Brawl Stars включён"
                    }
                } else {
                    stopService(Intent(this@MainActivity, BrawlWatcherService::class.java))
                    tvStatusBanner.text = "Автозапуск с Brawl Stars выключен"
                }
            }
        }
        permCard.addView(swAutoBrawl, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })

        tvPermOverlayStatus = TextView(this).apply { textSize = 13f; setPadding(0, 4, 0, 6) }
        permCard.addView(tvPermOverlayStatus)
        permCard.addView(
            styledButton("1) Разрешить Overlay (Поверх других окон)") { requestOverlayPermission() },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14 }
        )

        tvPermUsageStatus = TextView(this).apply { textSize = 13f; setPadding(0, 4, 0, 6) }
        permCard.addView(tvPermUsageStatus)
        permCard.addView(
            styledButton("2) Разрешить доступ к запуску игр (Usage Access)") { requestUsageAccessPermission() },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14 }
        )

        tvPermNotifStatus = TextView(this).apply { textSize = 13f; setPadding(0, 4, 0, 6) }
        permCard.addView(tvPermNotifStatus)
        permCard.addView(
            styledButton("3) Разрешить уведомления (Android 13+)") { requestNotificationPermission() },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14 }
        )

        tvPermCaptureStatus = TextView(this).apply { textSize = 13f; setPadding(0, 4, 0, 6) }
        permCard.addView(tvPermCaptureStatus)
        permCard.addView(
            styledButton("4) Запросить Screen Capture (MediaProjection)", accent = true) { requestScreenCapture() },
            LinearLayout.LayoutParams(-1, -2)
        )
        root.addView(permCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 18 })

        val modelCard = card()
        modelCard.addView(sectionTitle("2. ONNX-МОДЕЛЬ И RUNTIME"))

        tvModelInfo = TextView(this).apply {
            textSize = 13.5f
            setTextColor(amber)
            setPadding(0, 0, 0, 6)
        }
        tvRuntimeInfo = TextView(this).apply {
            textSize = 12.5f
            setTextColor(muted)
            setPadding(0, 0, 0, 12)
        }
        modelCard.addView(tvModelInfo)
        modelCard.addView(tvRuntimeInfo)

        modelCard.addView(
            styledButton("Выбрать свой файл модели (.onnx)") {
                modelPickerLauncher.launch(arrayOf("application/octet-stream", "*/*"))
            },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 }
        )

        swNnapi = Switch(this).apply {
            text = "Использовать NNAPI Execution Provider (с откатом на CPU)"
            textSize = 13.5f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 8)
            setOnCheckedChangeListener { _, isChecked ->
                HudSettings.update(this@MainActivity) { it.copy(useNnapi = isChecked) }
                if (DetectionHub.captureStatus.value == DetectionHub.CaptureStatus.ACTIVE) {
                    startService(Intent(this@MainActivity, ScreenCaptureService::class.java).apply {
                        action = ScreenCaptureService.ACTION_RELOAD_MODEL
                    })
                } else {
                    syncModelStatusToHub()
                }
            }
        }
        modelCard.addView(swNnapi)
        root.addView(modelCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 18 })

        val detectorCard = card()
        detectorCard.addView(sectionTitle("3. НАСТРОЙКА ИИ И ИНФЕРЕНСА"))

        tvConfValue = TextView(this).apply { textSize = 13f; setTextColor(Color.WHITE) }
        sbConf = SeekBar(this).apply {
            max = 90
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = (5 + progress) / 100f
                    tvConfValue.text = String.format(Locale.US, "Confidence Threshold: %.2f (%d%%)", v, (v * 100).toInt())
                    if (fromUser) {
                        HudSettings.update(this@MainActivity) { it.copy(confThreshold = v) }
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        detectorCard.addView(tvConfValue)
        detectorCard.addView(sbConf, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14 })

        tvIouValue = TextView(this).apply { textSize = 13f; setTextColor(Color.WHITE) }
        sbIou = SeekBar(this).apply {
            max = 90
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = (5 + progress) / 100f
                    tvIouValue.text = String.format(Locale.US, "IoU Threshold (NMS): %.2f (%d%%)", v, (v * 100).toInt())
                    if (fromUser) {
                        HudSettings.update(this@MainActivity) { it.copy(iouThreshold = v) }
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        detectorCard.addView(tvIouValue)
        detectorCard.addView(sbIou, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14 })

        detectorCard.addView(TextView(this).apply {
            text = "Target FPS (частота обработки кадров):"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 8)
        })

        val fpsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val fpsOptions = listOf(10, 15, 20, 30)
        val btnMap = mutableMapOf<Int, Button>()
        for (fps in fpsOptions) {
            val b = Button(this).apply {
                text = "$fps"
                textSize = 13f
                setOnClickListener {
                    HudSettings.update(this@MainActivity) { it.copy(targetFps = fps) }
                    updateFpsButtonsHighlight(fps)
                }
            }
            btnMap[fps] = b
            fpsRow.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply {
                leftMargin = 6
                rightMargin = 6
            })
        }
        fpsButtons = btnMap
        detectorCard.addView(fpsRow)
        root.addView(detectorCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 18 })

        val controlCard = card()
        controlCard.addView(sectionTitle("4. ЗАПУСК И ОСТАНОВКА ОКНА HUD / CAPTURE"))

        tvLiveMetrics = TextView(this).apply {
            text = "Телеметрия: ожидание запуска"
            textSize = 12.5f
            setTextColor(cyan)
            setPadding(0, 0, 0, 12)
        }
        controlCard.addView(tvLiveMetrics)

        val captureRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        captureRow.addView(
            styledButton("▶ Старт Capture", accent = true) { requestScreenCapture() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 8 }
        )
        captureRow.addView(
            styledButton("■ Стоп Capture") { stopScreenCapture() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 8 }
        )
        controlCard.addView(captureRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })

        val hudRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hudRow.addView(
            styledButton("▶ Открыть окно HUD", accent = true) { startHudServices() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 8 }
        )
        hudRow.addView(
            styledButton("■ Закрыть HUD") { stopHudServices() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 8 }
        )
        controlCard.addView(hudRow)
        root.addView(controlCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 18 })

        val hudCard = card()
        hudCard.addView(sectionTitle("5. НАСТРОЙКИ ОТОБРАЖЕНИЯ HUD"))

        cbBoxes = CheckBox(this).apply {
            text = "Показывать Bounding Boxes"
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked ->
                HudSettings.update(this@MainActivity) { it.copy(showBoxes = checked) }
            }
        }
        cbLabels = CheckBox(this).apply {
            text = "Показывать названия классов (Class Labels)"
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked ->
                HudSettings.update(this@MainActivity) { it.copy(showLabels = checked) }
            }
        }
        cbConfidence = CheckBox(this).apply {
            text = "Показывать Confidence (%)"
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked ->
                HudSettings.update(this@MainActivity) { it.copy(showConfidence = checked) }
            }
        }
        cbDebugCoords = CheckBox(this).apply {
            text = "Показывать координаты для debug"
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked ->
                HudSettings.update(this@MainActivity) { it.copy(showDebugCoords = checked) }
            }
        }
        hudCard.addView(cbBoxes)
        hudCard.addView(cbLabels)
        hudCard.addView(cbConfidence)
        hudCard.addView(cbDebugCoords)

        tvAlphaValue = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 0)
        }
        sbAlpha = SeekBar(this).apply {
            max = 75
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val alpha = (25 + progress) / 100f
                    tvAlphaValue.text = "Прозрачность HUD: ${(alpha * 100).toInt()}%"
                    if (fromUser) {
                        HudSettings.update(this@MainActivity) { it.copy(hudAlpha = alpha) }
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        hudCard.addView(tvAlphaValue)
        hudCard.addView(sbAlpha, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })

        tvScaleValue = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
        }
        sbScale = SeekBar(this).apply {
            max = 60
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val scale = (75 + progress) / 100f
                    tvScaleValue.text = "Масштаб HUD: ${(scale * 100).toInt()}%"
                    if (fromUser) {
                        HudSettings.update(this@MainActivity) { it.copy(hudScale = scale) }
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        hudCard.addView(tvScaleValue)
        hudCard.addView(sbScale)

        root.addView(hudCard)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun bindSettingsToUi() {
        val cfg = HudSettings.config.value
        swAutoBrawl.isChecked = cfg.autoLaunchOnBrawlStars

        sbConf.progress = ((cfg.confThreshold * 100).toInt() - 5).coerceIn(0, 90)
        tvConfValue.text = String.format(Locale.US, "Confidence Threshold: %.2f (%d%%)", cfg.confThreshold, (cfg.confThreshold * 100).toInt())

        sbIou.progress = ((cfg.iouThreshold * 100).toInt() - 5).coerceIn(0, 90)
        tvIouValue.text = String.format(Locale.US, "IoU Threshold (NMS): %.2f (%d%%)", cfg.iouThreshold, (cfg.iouThreshold * 100).toInt())

        updateFpsButtonsHighlight(cfg.targetFps)
        swNnapi.isChecked = cfg.useNnapi

        cbBoxes.isChecked = cfg.showBoxes
        cbLabels.isChecked = cfg.showLabels
        cbConfidence.isChecked = cfg.showConfidence
        cbDebugCoords.isChecked = cfg.showDebugCoords

        sbAlpha.progress = ((cfg.hudAlpha * 100).toInt() - 25).coerceIn(0, 75)
        tvAlphaValue.text = "Прозрачность HUD: ${(cfg.hudAlpha * 100).toInt()}%"

        sbScale.progress = ((cfg.hudScale * 100).toInt() - 75).coerceIn(0, 60)
        tvScaleValue.text = "Масштаб HUD: ${(cfg.hudScale * 100).toInt()}%"
    }

    private fun updateFpsButtonsHighlight(selectedFps: Int) {
        for ((fps, btn) in fpsButtons) {
            val active = fps == selectedFps
            btn.setTextColor(if (active) Color.rgb(5, 14, 26) else Color.WHITE)
            btn.background = GradientDrawable().apply {
                setColor(if (active) cyan else Color.rgb(22, 42, 70))
                cornerRadius = 14f
            }
        }
    }

    private fun observeHub() {
        lifecycleScope.launch {
            combine(
                DetectionHub.modelState,
                DetectionHub.captureStatus,
                DetectionHub.captureDetail,
                DetectionHub.telemetry,
            ) { model, capStatus, capDetail, tel ->
                Quad(model, capStatus, capDetail, tel)
            }.collect { (model, capStatus, capDetail, tel) ->
                if (model.loaded) {
                    tvModelInfo.text = "ONNX-модель: ${model.modelName}"
                    tvModelInfo.setTextColor(green)
                } else {
                    tvModelInfo.text = model.statusText
                    tvModelInfo.setTextColor(amber)
                }
                tvRuntimeInfo.text = "Runtime: ${model.runtimeProvider} • Статус: ${model.statusText}"

                tvPermCaptureStatus.text = "Статус Screen Capture: ${capStatus.label} ($capDetail)"
                tvPermCaptureStatus.setTextColor(
                    when (capStatus) {
                        DetectionHub.CaptureStatus.ACTIVE -> green
                        DetectionHub.CaptureStatus.ERROR -> red
                        else -> muted
                    }
                )

                val fpsStr = tel.fps?.let { String.format(Locale.US, "%.1f", it) } ?: "—"
                val infStr = tel.inferenceMs?.let { "${it}ms" } ?: "—"
                tvLiveMetrics.text = "FPS: $fpsStr | Inference: $infStr | Объектов: ${tel.objectCount}"
            }
        }
    }

    private data class Quad<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)

    private fun refreshPermissionsUi() {
        val overlayGranted = Settings.canDrawOverlays(this)
        tvPermOverlayStatus.text = if (overlayGranted) {
            "1. SYSTEM_ALERT_WINDOW (Overlay): РАЗРЕШЕНО"
        } else {
            "1. SYSTEM_ALERT_WINDOW (Overlay): ТРЕБУЕТСЯ РАЗРЕШЕНИЕ"
        }
        tvPermOverlayStatus.setTextColor(if (overlayGranted) green else amber)

        val usageGranted = hasUsageStatsPermission()
        tvPermUsageStatus.text = if (usageGranted) {
            "2. PACKAGE_USAGE_STATS (Автозапуск с Brawl Stars): РАЗРЕШЕНО"
        } else {
            "2. PACKAGE_USAGE_STATS (Автозапуск с Brawl Stars): ТРЕБУЕТСЯ РАЗРЕШЕНИЕ"
        }
        tvPermUsageStatus.setTextColor(if (usageGranted) green else amber)

        val notifGranted = if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        tvPermNotifStatus.text = if (notifGranted) {
            "3. POST_NOTIFICATIONS: РАЗРЕШЕНО"
        } else {
            "3. POST_NOTIFICATIONS: НЕ ВЫДАНО"
        }
        tvPermNotifStatus.setTextColor(if (notifGranted) green else amber)
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            refreshPermissionsUi()
            tvStatusBanner.text = "Разрешение Overlay уже активно"
        }
    }

    private fun requestUsageAccessPermission() {
        if (!hasUsageStatsPermission()) {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
            try {
                usageAccessLauncher.launch(intent)
            } catch (_: Exception) {
                usageAccessLauncher.launch(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        } else {
            refreshPermissionsUi()
            syncBrawlWatcherService()
            tvStatusBanner.text = "Доступ к статистике запусков уже активен"
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                refreshPermissionsUi()
                tvStatusBanner.text = "Разрешение на уведомления уже выдано"
            }
        } else {
            tvStatusBanner.text = "Для этой версии Android отдельное разрешение не требуется"
        }
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureConsentLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun stopScreenCapture() {
        startService(Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        })
        tvStatusBanner.text = "Команда остановки Screen Capture отправлена"
    }

    private fun startHudServices() {
        if (!Settings.canDrawOverlays(this)) {
            tvStatusBanner.text = "Сначала выдайте разрешение Overlay (шаг 1)"
            requestOverlayPermission()
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        if (HudSettings.config.value.showBoxes) {
            ContextCompat.startForegroundService(this, Intent(this, FloatingHudService::class.java))
        }
        tvStatusBanner.text = "Окно HUD с настройками ИИ открыто"
    }

    private fun stopHudServices() {
        stopService(Intent(this, OverlayService::class.java))
        stopService(Intent(this, FloatingHudService::class.java))
        tvStatusBanner.text = "Окно HUD закрыто"
    }
}
