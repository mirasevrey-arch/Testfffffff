package com.neonai.redmagic

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.neonai.vision.DetectionHub
import com.neonai.vision.DetectionPipeline
import com.neonai.vision.HudSettings

/**
 * Полноценный захват экрана через MediaProjection + ImageReader + DetectionPipeline.
 * - Регистрирует MediaProjection.Callback ДО создания VirtualDisplay (требование Android 14+/16).
 * - Корректно обрабатывает rowStride и pixelStride, обрезает padding до реальной ширины кадра.
 * - Освобождает Image в блоке finally, не накапливает очередь кадров.
 * - Поддерживает остановку из UI и из системного уведомления, а также перезапуск при смене ориентации.
 */
class ScreenCaptureService : Service() {

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var projectionCallback: MediaProjection.Callback? = null

    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private var pipeline: DetectionPipeline? = null

    private var captureWidth: Int = 0
    private var captureHeight: Int = 0
    private var captureDensity: Int = 0

    override fun onCreate() {
        super.onCreate()
        HudSettings.init(this)
        captureThread = HandlerThread("neon-screen-capture").apply { start() }
        captureHandler = Handler(captureThread!!.looper)
        pipeline = DetectionPipeline(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                releaseCapture(stopProjection = true)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RELOAD_MODEL -> {
                pipeline?.requestModelReload()
                return START_NOT_STICKY
            }
            ACTION_START -> Unit
            else -> {
                stopSelf()
                return START_NOT_STICKY
            }
        }

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null) {
            DetectionHub.setCaptureStatus(
                DetectionHub.CaptureStatus.ERROR,
                "Отсутствуют данные разрешения MediaProjection"
            )
            stopSelf()
            return START_NOT_STICKY
        }

        // Останавливаем предыдущую сессию при повторном запуске
        releaseCapture(stopProjection = true)

        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        DetectionHub.setCaptureStatus(DetectionHub.CaptureStatus.STARTING, "Инициализация MediaProjection...")

        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = manager.getMediaProjection(resultCode, data)
            if (mp == null) {
                DetectionHub.setCaptureStatus(
                    DetectionHub.CaptureStatus.ERROR,
                    "Система не вернула экземпляр MediaProjection"
                )
                stopSelf()
                return START_NOT_STICKY
            }
            projection = mp

            val callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.i(TAG, "MediaProjection stopped by system or user")
                    releaseCapture(stopProjection = false)
                    stopSelf()
                }
            }
            projectionCallback = callback
            // Обязательная регистрация Callback до createVirtualDisplay для Android 14+ / 16
            mp.registerCallback(callback, captureHandler)

            setupVirtualDisplay()
            DetectionHub.setCaptureStatus(
                DetectionHub.CaptureStatus.ACTIVE,
                "Захват ${captureWidth}×${captureHeight}"
            )
        } catch (error: Throwable) {
            Log.e(TAG, "Failed to start screen capture", error)
            DetectionHub.setCaptureStatus(
                DetectionHub.CaptureStatus.ERROR,
                "Ошибка захвата: ${error.message ?: "сбой инициализации"}"
            )
            releaseCapture(stopProjection = true)
            stopSelf()
        }

        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (projection != null) {
            val (w, h, d) = resolveScreenMetrics()
            if (w != captureWidth || h != captureHeight) {
                recreateVirtualDisplay(w, h, d)
            }
        }
    }

    private fun resolveScreenMetrics(): Triple<Int, Int, Int> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds: Rect = wm.maximumWindowMetrics.bounds
            val density = resources.configuration.densityDpi
            Triple(bounds.width(), bounds.height(), density)
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            Triple(metrics.widthPixels, metrics.heightPixels, metrics.densityDpi)
        }
    }

    private fun setupVirtualDisplay() {
        val (w, h, density) = resolveScreenMetrics()
        captureWidth = w
        captureHeight = h
        captureDensity = density

        val reader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        reader.setOnImageAvailableListener({ r ->
            val image = try {
                r.acquireLatestImage()
            } catch (_: Throwable) {
                null
            } ?: return@setOnImageAvailableListener

            try {
                val planes = image.planes
                if (planes.isEmpty()) return@setOnImageAvailableListener
                val plane = planes[0]
                val buffer = plane.buffer ?: return@setOnImageAvailableListener
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                if (pixelStride <= 0) return@setOnImageAvailableListener

                val imgW = image.width
                val imgH = image.height
                val rowPadding = rowStride - pixelStride * imgW
                val paddedWidth = imgW + rowPadding / pixelStride

                val paddedBitmap = Bitmap.createBitmap(paddedWidth, imgH, Bitmap.Config.ARGB_8888)
                buffer.rewind()
                paddedBitmap.copyPixelsFromBuffer(buffer)

                val finalBitmap = if (paddedWidth != imgW) {
                    val cropped = Bitmap.createBitmap(paddedBitmap, 0, 0, imgW, imgH)
                    paddedBitmap.recycle()
                    cropped
                } else {
                    paddedBitmap
                }

                val currentPipeline = pipeline
                if (currentPipeline != null) {
                    currentPipeline.submit(finalBitmap)
                } else {
                    finalBitmap.recycle()
                }
            } catch (e: Throwable) {
                Log.w(TAG, "Frame conversion failed: ${e.message}")
            } finally {
                try {
                    image.close()
                } catch (_: Throwable) {
                }
            }
        }, captureHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "NEON_AI_CAPTURE",
            captureWidth,
            captureHeight,
            captureDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            captureHandler
        )
    }

    private fun recreateVirtualDisplay(newW: Int, newH: Int, newDensity: Int) {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
            imageReader = null

            captureWidth = newW
            captureHeight = newH
            captureDensity = newDensity
            setupVirtualDisplay()
            DetectionHub.setCaptureStatus(
                DetectionHub.CaptureStatus.ACTIVE,
                "Захват ${captureWidth}×${captureHeight}"
            )
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to recreate VirtualDisplay after rotation", e)
        }
    }

    private fun releaseCapture(stopProjection: Boolean = true) {
        try {
            virtualDisplay?.release()
        } catch (_: Throwable) {
        }
        virtualDisplay = null

        try {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
        } catch (_: Throwable) {
        }
        imageReader = null

        val currentProjection = projection
        projectionCallback?.let { cb ->
            try {
                currentProjection?.unregisterCallback(cb)
            } catch (_: Throwable) {
            }
        }
        projectionCallback = null
        projection = null

        if (stopProjection) {
            try {
                currentProjection?.stop()
            } catch (_: Throwable) {
            }
        }

        DetectionHub.setCaptureStatus(DetectionHub.CaptureStatus.STOPPED, "Захват экрана остановлен")
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            101,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openAppIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this,
            102,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NEON AI • Захват экрана")
            .setContentText("Поток кадров передаётся в локальный YOLO-детектор")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(openPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Остановить", stopPending)
            .setOngoing(true)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "NEON AI Screen Capture",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        releaseCapture(stopProjection = true)
        pipeline?.release()
        pipeline = null
        captureThread?.quitSafely()
        captureThread = null
        captureHandler = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "NEON_AI_CAPTURE"
        const val ACTION_START = "com.neonai.redmagic.START_CAPTURE"
        const val ACTION_STOP = "com.neonai.redmagic.STOP_CAPTURE"
        const val ACTION_RELOAD_MODEL = "com.neonai.redmagic.RELOAD_MODEL"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val NOTIFICATION_ID = 12
        private const val CHANNEL_ID = "neon_capture"
    }
}
