package com.neonai.redmagic

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.neonai.vision.DetectionHub
import com.neonai.vision.DetectionResult
import com.neonai.vision.FloatingHudService
import com.neonai.vision.HudSettings
import com.neonai.vision.ModelManager
import com.neonai.vision.NeonConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Плавающее окно управления и настройки ИИ поверх других приложений (включая Brawl Stars).
 * Показывает:
 * - статус ONNX-модели, автозапуска с игрой, Screen Capture, FPS, Inference Time, Detected Objects, Confidence;
 * - быструю настройку порога уверенности (Confidence) и частоты FPS прямо в окне HUD;
 * - переключатели рамок, меток классов, confidence, debug-координат;
 * - сворачивание в компактную кнопку и перетаскивание по экрану.
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private lateinit var header: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var toggleBtn: TextView
    private lateinit var params: WindowManager.LayoutParams
    private var expanded = true

    private lateinit var tvAiAnalysis: TextView
    private lateinit var tvYoloEngine: TextView
    private lateinit var tvScreenCapture: TextView
    private lateinit var tvModelStatus: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvInferenceTime: TextView
    private lateinit var tvDetectedCount: TextView
    private lateinit var tvConfidence: TextView
    private lateinit var tvObjectsList: TextView

    private lateinit var tvHudConf: TextView
    private lateinit var sbHudConf: SeekBar
    private lateinit var btnHudFps: TextView
    private lateinit var btnHudNnapi: TextView

    private lateinit var btnBoxes: TextView
    private lateinit var btnLabels: TextView
    private lateinit var btnConf: TextView
    private lateinit var btnDebugCoords: TextView
    private lateinit var btnCaptureAction: TextView

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val cyan = Color.rgb(0, 229, 255)
    private val green = Color.rgb(52, 199, 89)
    private val amber = Color.rgb(255, 190, 70)
    private val red = Color.rgb(255, 69, 58)
    private val muted = Color.rgb(160, 177, 199)

    override fun onCreate() {
        super.onCreate()
        HudSettings.init(this)
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (HudSettings.config.value.showBoxes && !DetectionHub.hudBoxesServiceRunning.value) {
            ContextCompat.startForegroundService(this, Intent(this, FloatingHudService::class.java))
        }

        showPanel()
        DetectionHub.setHudPanelRunning(true)
        observeHub()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopService(Intent(this, FloatingHudService::class.java))
            stopSelf()
            return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }

    private fun observeHub() {
        scope.launch {
            combine(
                DetectionHub.captureStatus,
                DetectionHub.captureDetail,
                DetectionHub.modelState,
                DetectionHub.telemetry,
                DetectionHub.frames,
            ) { capStatus, capDetail, modelState, telemetry, frame ->
                HudSnapshot(capStatus, capDetail, modelState, telemetry, frame)
            }.collect { snap ->
                applyTelemetry(snap)
            }
        }

        scope.launch {
            HudSettings.config.collect { cfg ->
                applyConfig(cfg)
            }
        }
    }

    private data class HudSnapshot(
        val capStatus: DetectionHub.CaptureStatus,
        val capDetail: String,
        val modelState: DetectionHub.ModelState,
        val telemetry: DetectionHub.TelemetryState,
        val frame: DetectionResult?,
    )

    private fun applyConfig(cfg: NeonConfig) {
        if (!::btnBoxes.isInitialized) return
        root?.alpha = cfg.hudAlpha.coerceIn(0.35f, 1.0f)
        tvHudConf.text = String.format(Locale.US, "Порог ИИ (Conf): %d%%", (cfg.confThreshold * 100).toInt())
        if (!sbHudConf.isPressed) {
            sbHudConf.progress = ((cfg.confThreshold * 100).toInt() - 5).coerceIn(0, 90)
        }
        btnHudFps.text = "FPS цели: ${cfg.targetFps} (нажми для смены)"
        btnHudNnapi.text = if (cfg.useNnapi) "NNAPI: ВКЛ" else "NNAPI: ВЫКЛ (CPU)"
        btnBoxes.text = if (cfg.showBoxes) "☑ Рамки (Boxes): ВКЛ" else "□ Рамки (Boxes): ВЫКЛ"
        btnLabels.text = if (cfg.showLabels) "☑ Классы (Labels): ВКЛ" else "□ Классы (Labels): ВЫКЛ"
        btnConf.text = if (cfg.showConfidence) "☑ Уверенность (%): ВКЛ" else "□ Уверенность (%): ВЫКЛ"
        btnDebugCoords.text = if (cfg.showDebugCoords) "☑ Debug-координаты: ВКЛ" else "□ Debug-координаты: ВЫКЛ"
    }

    private fun applyTelemetry(snap: HudSnapshot) {
        if (!::tvAiAnalysis.isInitialized) return

        val captureActive = snap.capStatus == DetectionHub.CaptureStatus.ACTIVE
        val modelLoaded = snap.modelState.loaded
        val aiRunning = captureActive && modelLoaded

        when {
            aiRunning -> {
                tvAiAnalysis.text = "АКТИВЕН"
                tvAiAnalysis.setTextColor(green)
            }
            !modelLoaded -> {
                tvAiAnalysis.text = "НЕТ МОДЕЛИ"
                tvAiAnalysis.setTextColor(amber)
            }
            else -> {
                tvAiAnalysis.text = "ОЖИДАНИЕ CAPTURE"
                tvAiAnalysis.setTextColor(muted)
            }
        }

        tvYoloEngine.text = if (modelLoaded) snap.modelState.runtimeProvider else "НЕ ЗАГРУЖЕН"
        tvYoloEngine.setTextColor(if (modelLoaded) cyan else amber)

        tvScreenCapture.text = snap.capStatus.label
        tvScreenCapture.setTextColor(
            when (snap.capStatus) {
                DetectionHub.CaptureStatus.ACTIVE -> green
                DetectionHub.CaptureStatus.STARTING -> amber
                DetectionHub.CaptureStatus.ERROR -> red
                DetectionHub.CaptureStatus.STOPPED -> muted
            }
        )

        tvModelStatus.text = if (modelLoaded) {
            "ONNX: ${snap.modelState.modelName}"
        } else {
            snap.modelState.statusText
        }
        tvModelStatus.setTextColor(if (modelLoaded) cyan else amber)

        val fpsVal = snap.telemetry.fps
        tvFps.text = if (aiRunning && fpsVal != null && fpsVal > 0f) {
            String.format(Locale.US, "%.1f FPS", fpsVal)
        } else {
            "—"
        }

        val infMs = snap.telemetry.inferenceMs
        tvInferenceTime.text = if (aiRunning && infMs != null) {
            "$infMs ms"
        } else {
            "—"
        }

        val count = if (aiRunning) snap.telemetry.objectCount else 0
        tvDetectedCount.text = if (aiRunning) "$count" else "0"

        val avgConf = snap.telemetry.avgConfidence
        tvConfidence.text = if (aiRunning && avgConf != null) {
            "${(avgConf * 100).toInt()}%"
        } else {
            "—"
        }

        val dets = if (aiRunning) snap.frame?.detections.orEmpty() else emptyList()
        if (!modelLoaded) {
            tvObjectsList.text = "Объекты: выберите .onnx в настройках"
        } else if (!captureActive) {
            tvObjectsList.text = "Объекты: включите Screen Capture для детекции"
        } else if (dets.isEmpty()) {
            tvObjectsList.text = "Объекты: не обнаружены"
        } else {
            val lines = dets.take(8).mapIndexed { idx, d ->
                val pct = (d.confidence * 100).toInt()
                val coords = "(${d.box.left.toInt()},${d.box.top.toInt()})-(${d.box.right.toInt()},${d.box.bottom.toInt()})"
                "${idx + 1}. ${d.label} $pct% $coords"
            }
            val extra = if (dets.size > 8) "\n... и ещё ${dets.size - 8}" else ""
            tvObjectsList.text = lines.joinToString("\n") + extra
        }

        btnCaptureAction.text = if (captureActive) {
            "■ ОСТАНОВИТЬ CAPTURE"
        } else {
            "▶ ОТКРЫТЬ НАСТРОЙКИ / CAPTURE"
        }
    }

    private fun bg(color: Int, radius: Float, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (stroke != 0) setStroke(2, stroke)
        }

    private fun labelText(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun actionButton(label: String, onClick: () -> Unit): TextView =
        labelText(label, 11.5f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(12, 9, 12, 9)
            background = bg(Color.rgb(18, 36, 58), 14f, Color.rgb(0, 135, 175))
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }

    private fun metricRow(title: String, valueView: TextView): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(2, 4, 2, 4)
            addView(labelText(title, 11.5f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
            addView(valueView)
        }

    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val scale = HudSettings.config.value.hudScale.coerceIn(0.75f, 1.35f)
        val panelWidthPx = (300 * resources.displayMetrics.density * scale).toInt()

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 12)
            background = bg(Color.argb(242, 7, 13, 27), 20f, cyan)
            alpha = HudSettings.config.value.hudAlpha
        }

        header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true
            addView(labelText("✦ NEON AI • HUD", 14.5f, cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
            toggleBtn = actionButton("−") { toggleExpanded() }
            addView(toggleBtn, LinearLayout.LayoutParams(44, 38))
        }
        shell.addView(header)

        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 6, 0, 0)
        }

        tvAiAnalysis = labelText("ОЖИДАНИЕ", 11.5f, amber, true)
        tvYoloEngine = labelText("—", 11.5f, cyan, true)
        tvScreenCapture = labelText("ОСТАНОВЛЕН", 11.5f, muted, true)
        tvFps = labelText("—", 11.5f, green, true)
        tvInferenceTime = labelText("—", 11.5f, cyan, true)
        tvDetectedCount = labelText("0", 11.5f, Color.WHITE, true)
        tvConfidence = labelText("—", 11.5f, cyan, true)

        tvModelStatus = labelText(ModelManager.MISSING_MODEL_MESSAGE, 10.5f, amber, false).apply {
            setPadding(2, 4, 2, 6)
        }

        tvObjectsList = labelText("Объекты: ожидание запуска", 10.5f, Color.rgb(215, 228, 245), false).apply {
            setPadding(8, 6, 8, 6)
            background = bg(Color.argb(160, 13, 24, 44), 12f, Color.rgb(26, 56, 88))
        }

        val scrollObjects = ScrollView(this).apply {
            addView(tvObjectsList)
        }

        body.addView(tvModelStatus)
        body.addView(metricRow("AI Analysis", tvAiAnalysis))
        body.addView(metricRow("ONNX Engine", tvYoloEngine))
        body.addView(metricRow("Screen Capture", tvScreenCapture))
        body.addView(metricRow("FPS", tvFps))
        body.addView(metricRow("Inference Time", tvInferenceTime))
        body.addView(metricRow("Detected Objects", tvDetectedCount))
        body.addView(metricRow("Confidence", tvConfidence))

        body.addView(
            scrollObjects,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (92 * resources.displayMetrics.density).toInt()
            ).apply { topMargin = 6; bottomMargin = 8 }
        )

        tvHudConf = labelText("Порог ИИ (Conf): 30%", 11f, Color.WHITE, true).apply {
            setPadding(2, 2, 2, 2)
        }
        sbHudConf = SeekBar(this).apply {
            max = 90
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = (5 + progress) / 100f
                    tvHudConf.text = String.format(Locale.US, "Порог ИИ (Conf): %d%%", (v * 100).toInt())
                    if (fromUser) {
                        HudSettings.update(this@OverlayService) { it.copy(confThreshold = v) }
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        body.addView(tvHudConf)
        body.addView(sbHudConf, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 })

        btnHudFps = actionButton("FPS цели: 15 (нажми для смены)") {
            val order = listOf(10, 15, 20, 30)
            val cur = HudSettings.config.value.targetFps
            val next = order[(order.indexOf(cur) + 1).mod(order.size)]
            HudSettings.update(this) { it.copy(targetFps = next) }
        }
        body.addView(btnHudFps, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5 })

        btnHudNnapi = actionButton("NNAPI: ВЫКЛ (CPU)") {
            val next = !HudSettings.config.value.useNnapi
            HudSettings.update(this) { it.copy(useNnapi = next) }
            if (DetectionHub.captureStatus.value == DetectionHub.CaptureStatus.ACTIVE) {
                startService(Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_RELOAD_MODEL
                })
            }
        }
        body.addView(btnHudNnapi, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 })

        btnBoxes = actionButton("☑ Рамки (Boxes): ВКЛ") {
            val next = !HudSettings.config.value.showBoxes
            HudSettings.update(this) { it.copy(showBoxes = next) }
            if (next && Settings.canDrawOverlays(this)) {
                ContextCompat.startForegroundService(this, Intent(this, FloatingHudService::class.java))
            } else {
                stopService(Intent(this, FloatingHudService::class.java))
            }
        }
        body.addView(btnBoxes, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5 })

        btnLabels = actionButton("☑ Классы (Labels): ВКЛ") {
            val next = !HudSettings.config.value.showLabels
            HudSettings.update(this) { it.copy(showLabels = next) }
        }
        body.addView(btnLabels, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5 })

        btnConf = actionButton("☑ Уверенность (%): ВКЛ") {
            val next = !HudSettings.config.value.showConfidence
            HudSettings.update(this) { it.copy(showConfidence = next) }
        }
        body.addView(btnConf, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5 })

        btnDebugCoords = actionButton("□ Debug-координаты: ВЫКЛ") {
            val next = !HudSettings.config.value.showDebugCoords
            HudSettings.update(this) { it.copy(showDebugCoords = next) }
        }
        body.addView(btnDebugCoords, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 })

        btnCaptureAction = actionButton("▶ ОТКРЫТЬ НАСТРОЙКИ / CAPTURE") {
            if (DetectionHub.captureStatus.value == DetectionHub.CaptureStatus.ACTIVE) {
                startService(Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_STOP
                })
            } else {
                startActivity(Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                })
            }
        }
        body.addView(btnCaptureAction, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5 })

        val btnHide = actionButton("✕ ЗАКРЫТЬ HUD") {
            stopService(Intent(this, FloatingHudService::class.java))
            stopSelf()
        }
        body.addView(btnHide, LinearLayout.LayoutParams(-1, -2))

        shell.addView(body)
        root = shell

        params = WindowManager.LayoutParams(
            panelWidthPx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 140
        }

        installDrag(header)
        applyConfig(HudSettings.config.value)
        wm.addView(shell, params)
    }

    private fun toggleExpanded() {
        expanded = !expanded
        body.visibility = if (expanded) View.VISIBLE else View.GONE
        toggleBtn.text = if (expanded) "−" else "◈"
        val density = resources.displayMetrics.density
        if (expanded) {
            val scale = HudSettings.config.value.hudScale.coerceIn(0.75f, 1.35f)
            params.width = (292 * density * scale).toInt()
            root?.setPadding((14 * density).toInt(), (10 * density).toInt(), (14 * density).toInt(), (12 * density).toInt())
            root?.background = bg(Color.argb(242, 7, 13, 27), 20f * density, cyan)
        } else {
            params.width = WindowManager.LayoutParams.WRAP_CONTENT
            root?.setPadding((12 * density).toInt(), (7 * density).toInt(), (12 * density).toInt(), (7 * density).toInt())
            root?.background = bg(Color.argb(235, 9, 17, 34), 999f, cyan)
        }
        root?.let {
            try {
                wm.updateViewLayout(it, params)
            } catch (_: Exception) {
            }
        }
    }

    private fun installDrag(view: View) {
        var downX = 0
        var downY = 0
        var startX = 0
        var startY = 0
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX.toInt()
                    downY = event.rawY.toInt()
                    startX = params.x
                    startY = params.y
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + event.rawX.toInt() - downX
                    params.y = startY + event.rawY.toInt() - downY
                    try {
                        root?.let { wm.updateViewLayout(it, params) }
                    } catch (_: Exception) {
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, OverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            201,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NEON AI • Плавающий HUD")
            .setContentText("Окно управления и настройки ИИ активно")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Закрыть HUD", stopPending)
            .setOngoing(true)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "NEON AI HUD Panel", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        DetectionHub.setHudPanelRunning(false)
        scope.cancel()
        root?.let {
            try {
                if (::wm.isInitialized) wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        root = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.neonai.redmagic.STOP_OVERLAY"
        private const val NOTIFICATION_ID = 11
        private const val CHANNEL_ID = "neon_overlay"
    }
}
