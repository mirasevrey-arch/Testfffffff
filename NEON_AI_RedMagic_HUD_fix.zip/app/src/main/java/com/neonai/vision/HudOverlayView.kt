package com.neonai.vision

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.abs

/**
 * Прозрачный полноэкранный слой отрисовки настоящих bounding boxes, классов, confidence и координат.
 * Если модель не загружена или детекций нет — ничего не рисует.
 */
class HudOverlayView(context: Context) : View(context) {

    private var result: DetectionResult? = null
    private var config: NeonConfig = HudSettings.config.value
    private var modelLoaded: Boolean = false

    private val colors = intArrayOf(
        Color.rgb(0, 229, 255),   // 0: brawler
        Color.rgb(255, 59, 48),   // 1: enemy
        Color.rgb(10, 132, 255),  // 2: teammate
        Color.rgb(255, 214, 10),  // 3: projectile
        Color.rgb(174, 174, 178), // 4: obstacle
        Color.rgb(52, 199, 89),   // 5: bush
        Color.rgb(255, 159, 10),  // 6: health_bar
        Color.rgb(191, 90, 242),  // 7: super_indicator
    )

    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
    }

    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 26f
        color = Color.WHITE
        isFakeBoldText = true
    }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    fun updateState(r: DetectionResult?, cfg: NeonConfig, isModelLoaded: Boolean) {
        result = r
        config = cfg
        modelLoaded = isModelLoaded
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (!modelLoaded || !config.showBoxes) return
        val r = result ?: return
        if (r.detections.isEmpty() || r.sourceWidth <= 0 || r.sourceHeight <= 0 || width <= 0 || height <= 0) return

        val viewW = width.toFloat()
        val viewH = height.toFloat()
        val srcW = r.sourceWidth.toFloat()
        val srcH = r.sourceHeight.toFloat()

        // Учитываем возможное несовпадение ориентации или пропорций (letterbox/aspect mapping)
        val viewLandscape = viewW > viewH
        val srcLandscape = srcW > srcH

        val scaleX: Float
        val scaleY: Float
        val offsetX: Float
        val offsetY: Float

        if (viewLandscape == srcLandscape) {
            val viewAspect = viewW / viewH
            val srcAspect = srcW / srcH
            if (abs(viewAspect - srcAspect) < 0.02f) {
                scaleX = viewW / srcW
                scaleY = viewH / srcH
                offsetX = 0f
                offsetY = 0f
            } else if (srcAspect > viewAspect) {
                scaleX = viewW / srcW
                scaleY = scaleX
                offsetX = 0f
                offsetY = (viewH - srcH * scaleY) / 2f
            } else {
                scaleY = viewH / srcH
                scaleX = scaleY
                offsetX = (viewW - srcW * scaleX) / 2f
                offsetY = 0f
            }
        } else {
            scaleX = viewW / srcW
            scaleY = viewH / srcH
            offsetX = 0f
            offsetY = 0f
        }

        val alphaInt = (config.hudAlpha.coerceIn(0.25f, 1.0f) * 255).toInt()
        textPaint.textSize = 25f * config.hudScale

        for (d in r.detections) {
            val baseColor = colors[d.classId.mod(colors.size)]
            val strokeColor = Color.argb(alphaInt, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))
            val tagBgColor = Color.argb((alphaInt * 0.85f).toInt(), Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))

            boxPaint.color = strokeColor
            cornerPaint.color = strokeColor

            val l = (d.box.left * scaleX + offsetX).coerceIn(0f, viewW)
            val t = (d.box.top * scaleY + offsetY).coerceIn(0f, viewH)
            val rr = (d.box.right * scaleX + offsetX).coerceIn(0f, viewW)
            val b = (d.box.bottom * scaleY + offsetY).coerceIn(0f, viewH)

            if (rr - l < 2f || b - t < 2f) continue

            val rect = RectF(l, t, rr, b)
            bgPaint.color = Color.argb((alphaInt * 0.14f).toInt().coerceIn(0, 255), Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))
            canvas.drawRect(rect, bgPaint)
            canvas.drawRect(rect, boxPaint)

            // Акцентные уголки для читаемости поверх игрового фона
            val cornerLen = minOf(18f, (rr - l) * 0.25f, (b - t) * 0.25f)
            canvas.drawLine(l, t, l + cornerLen, t, cornerPaint)
            canvas.drawLine(l, t, l, t + cornerLen, cornerPaint)
            canvas.drawLine(rr, t, rr - cornerLen, t, cornerPaint)
            canvas.drawLine(rr, t, rr, t + cornerLen, cornerPaint)
            canvas.drawLine(l, b, l + cornerLen, b, cornerPaint)
            canvas.drawLine(l, b, l, b - cornerLen, cornerPaint)
            canvas.drawLine(rr, b, rr - cornerLen, b, cornerPaint)
            canvas.drawLine(rr, b, rr, b - cornerLen, cornerPaint)

            val parts = ArrayList<String>(3)
            if (config.showLabels) parts.add(d.label)
            if (config.showConfidence) parts.add("${(d.confidence * 100).toInt()}%")
            if (config.showDebugCoords) {
                parts.add("[${d.box.left.toInt()},${d.box.top.toInt()}-${d.box.right.toInt()},${d.box.bottom.toInt()}]")
            }

            if (parts.isNotEmpty()) {
                val caption = parts.joinToString(" ")
                val tw = textPaint.measureText(caption)
                val tagH = textPaint.textSize + 10f
                val tagTop = if (t - tagH >= 0f) t - tagH else t
                val tagBottom = tagTop + tagH
                val tagRight = (l + tw + 14f).coerceAtMost(viewW)
                val tagLeft = (tagRight - (tw + 14f)).coerceAtLeast(0f)

                bgPaint.color = tagBgColor
                canvas.drawRoundRect(RectF(tagLeft, tagTop, tagRight, tagBottom), 6f, 6f, bgPaint)
                textPaint.alpha = alphaInt
                canvas.drawText(caption, tagLeft + 7f, tagBottom - 7f, textPaint)
            }
        }
    }
}
