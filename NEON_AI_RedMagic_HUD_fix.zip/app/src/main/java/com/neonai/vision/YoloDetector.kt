package com.neonai.vision

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Детектор на ONNX Runtime для модели YOLO11, экспортированной через export.py
 * (выход без NMS: [1, 4+nc, 8400] или [1, 8400, 4+nc]; cx, cy, w, h в пикселях входа).
 */
class YoloDetector(
    context: Context,
    modelAsset: String? = null,
    modelFilePath: String? = null,
    labelsAsset: String = "labels.txt",
    private val inputSize: Int = 640,
    @Volatile var confThreshold: Float = 0.30f,
    @Volatile var iouThreshold: Float = 0.45f,
    private val maxDetections: Int = 100,
    useNnapi: Boolean = false,
) : AutoCloseable {

    val labels: List<String> = context.assets.open(labelsAsset).bufferedReader().useLines { lines ->
        lines.map { it.trim() }.filter { it.isNotEmpty() }.toList()
    }

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private var session: OrtSession
    private var inputName: String
    private var activeProvider: String = "CPU"
    private var closed = false

    val executionProvider: String
        get() = activeProvider

    // Переиспользуемые буферы для минимизации нагрузки на GC
    private val inputBuffer: FloatBuffer =
        ByteBuffer.allocateDirect(4 * 3 * inputSize * inputSize).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val letterBitmap = Bitmap.createBitmap(inputSize, inputSize, Bitmap.Config.ARGB_8888)
    private val letterCanvas = Canvas(letterBitmap)
    private val pixels = IntArray(inputSize * inputSize)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    init {
        val modelBytes = when {
            modelFilePath != null -> {
                val f = File(modelFilePath)
                require(f.exists() && f.length() > 0L) { "Файл модели не существует или пуст: $modelFilePath" }
                f.readBytes()
            }
            modelAsset != null -> context.assets.open(modelAsset).use { it.readBytes() }
            else -> throw IllegalArgumentException(ModelManager.MISSING_MODEL_MESSAGE)
        }

        val created = createSessionWithFallback(modelBytes, useNnapi)
        session = created.first
        activeProvider = created.second
        inputName = session.inputNames.first()
        validateModelMetadata()
    }

    private fun createSessionWithFallback(modelBytes: ByteArray, requestNnapi: Boolean): Pair<OrtSession, String> {
        if (requestNnapi) {
            try {
                val nnapiOpts = OrtSession.SessionOptions().apply {
                    setIntraOpNumThreads(4)
                    setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                    addNnapi()
                }
                val nnapiSession = env.createSession(modelBytes, nnapiOpts)
                return nnapiSession to "NNAPI (fallback CPU при ошибке инференса)"
            } catch (_: Throwable) {
                // Корректный откат на CPU при невозможности инициализации NNAPI
            }
        }
        val cpuOpts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(4)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        val cpuSession = env.createSession(modelBytes, cpuOpts)
        val status = if (requestNnapi) "CPU (NNAPI недоступен)" else "CPU"
        return cpuSession to status
    }

    private fun validateModelMetadata() {
        require(session.inputNames.isNotEmpty()) { "ONNX-модель не содержит входных тензоров" }
        require(session.outputNames.isNotEmpty()) { "ONNX-модель не содержит выходных тензоров" }
        require(labels.isNotEmpty()) { "Файл labels.txt пуст" }
    }

    private class Letterbox(val scale: Float, val padX: Int, val padY: Int)

    /** Bitmap -> letterbox 640×640 (серый 114, идентично common.py) -> RGB float NCHW 0..1. */
    private fun preprocess(src: Bitmap): Letterbox {
        val s = if (src.config == Bitmap.Config.HARDWARE) src.copy(Bitmap.Config.ARGB_8888, false) else src
        val scale = min(inputSize.toFloat() / s.width, inputSize.toFloat() / s.height)
        val newW = (s.width * scale).roundToInt()
        val newH = (s.height * scale).roundToInt()
        val padX = (inputSize - newW) / 2
        val padY = (inputSize - newH) / 2

        letterCanvas.drawColor(Color.rgb(114, 114, 114))
        letterCanvas.drawBitmap(
            s,
            null,
            RectF(padX.toFloat(), padY.toFloat(), (padX + newW).toFloat(), (padY + newH).toFloat()),
            paint
        )
        letterBitmap.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize)

        val plane = inputSize * inputSize
        inputBuffer.rewind()
        for (i in 0 until plane) {
            val p = pixels[i]
            inputBuffer.put(i, ((p shr 16) and 0xFF) / 255f)
            inputBuffer.put(plane + i, ((p shr 8) and 0xFF) / 255f)
            inputBuffer.put(2 * plane + i, (p and 0xFF) / 255f)
        }
        inputBuffer.rewind()
        if (s !== src) s.recycle()
        return Letterbox(scale, padX, padY)
    }

    @Synchronized
    fun detect(bitmap: Bitmap): DetectionResult {
        check(!closed) { "YoloDetector уже закрыт" }
        val t0 = SystemClock.elapsedRealtime()
        val lb = preprocess(bitmap)
        val shape = longArrayOf(1, 3, inputSize.toLong(), inputSize.toLong())

        OnnxTensor.createTensor(env, inputBuffer, shape).use { input ->
            val outputResult = try {
                session.run(mapOf(inputName to input))
            } catch (e: Throwable) {
                if (activeProvider.startsWith("NNAPI")) {
                    // Если инференс упал на NNAPI в рантайме, пересоздаём сессию на CPU
                    throw IllegalStateException("NNAPI runtime failure: ${e.message}", e)
                }
                throw e
            }
            outputResult.use { out ->
                val tensor = out[0] as OnnxTensor
                val dets = decode(tensor, lb, bitmap.width, bitmap.height)
                if (activeProvider.startsWith("NNAPI (")) {
                    activeProvider = "NNAPI"
                }
                return DetectionResult(
                    detections = dets,
                    sourceWidth = bitmap.width,
                    sourceHeight = bitmap.height,
                    inferenceMs = SystemClock.elapsedRealtime() - t0
                )
            }
        }
    }

    /** Декодирование выхода YOLO11 (без objectness): [1, 4+nc, N] или [1, N, 4+nc]. */
    private fun decode(t: OnnxTensor, lb: Letterbox, srcW: Int, srcH: Int): List<Detection> {
        val nc = labels.size
        val attrs = 4 + nc
        val shape = t.info.shape
        require(shape.size == 3) { "Неподдерживаемая размерность выхода модели: ${shape.contentToString()}" }

        val channelsFirst = shape[1].toInt() == attrs
        val channelsLast = shape[2].toInt() == attrs
        require(channelsFirst || channelsLast) {
            "Несовпадение числа классов модели и labels.txt ($nc классов, attrs=$attrs, shape=${shape.contentToString()})"
        }

        val n = if (channelsFirst) shape[2].toInt() else shape[1].toInt()
        val buf = t.floatBuffer
        val currentConf = confThreshold

        fun v(channel: Int, i: Int): Float =
            if (channelsFirst) buf.get(channel * n + i) else buf.get(i * attrs + channel)

        val candidates = ArrayList<Detection>()
        for (i in 0 until n) {
            var best = -1
            var bestScore = currentConf
            for (c in 0 until nc) {
                val sc = v(4 + c, i)
                if (sc > bestScore) {
                    bestScore = sc
                    best = c
                }
            }
            if (best < 0) continue

            val cx = v(0, i)
            val cy = v(1, i)
            val w = v(2, i)
            val h = v(3, i)

            val x1 = ((cx - w / 2f) - lb.padX) / lb.scale
            val y1 = ((cy - h / 2f) - lb.padY) / lb.scale
            val x2 = ((cx + w / 2f) - lb.padX) / lb.scale
            val y2 = ((cy + h / 2f) - lb.padY) / lb.scale

            val box = RectF(
                x1.coerceIn(0f, srcW.toFloat()),
                y1.coerceIn(0f, srcH.toFloat()),
                x2.coerceIn(0f, srcW.toFloat()),
                y2.coerceIn(0f, srcH.toFloat()),
            )
            if (box.width() < 1f || box.height() < 1f) continue
            candidates += Detection(box, best, labels[best], bestScore)
        }
        return nms(candidates)
    }

    /** Классовый NMS с актуальным iouThreshold. */
    private fun nms(dets: List<Detection>): List<Detection> {
        val currentIou = iouThreshold
        val sorted = dets.sortedByDescending { it.confidence }.take(300)
        val kept = ArrayList<Detection>()
        for (d in sorted) {
            if (kept.size >= maxDetections) break
            if (kept.none { it.classId == d.classId && iou(it.box, d.box) > currentIou }) {
                kept += d
            }
        }
        return kept
    }

    private fun iou(a: RectF, b: RectF): Float {
        val iw = max(0f, min(a.right, b.right) - max(a.left, b.left))
        val ih = max(0f, min(a.bottom, b.bottom) - max(a.top, b.top))
        val inter = iw * ih
        val union = a.width() * a.height() + b.width() * b.height() - inter
        return if (union <= 0f) 0f else inter / union
    }

    @Synchronized
    override fun close() {
        if (closed) return
        closed = true
        try { session.close() } catch (_: Exception) {}
        if (!letterBitmap.isRecycled) {
            letterBitmap.recycle()
        }
    }
}
