package com.neonai.vision

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Центральная реактивная шина состояния NEON AI: результаты детектора, статус модели и захвата. */
object DetectionHub {

    enum class CaptureStatus(val label: String) {
        STOPPED("ОСТАНОВЛЕН"),
        STARTING("ЗАПУСК..."),
        ACTIVE("АКТИВЕН"),
        ERROR("ОШИБКА"),
    }

    data class ModelState(
        val loaded: Boolean = false,
        val modelName: String? = null,
        val runtimeProvider: String = "—",
        val statusText: String = ModelManager.MISSING_MODEL_MESSAGE,
    )

    data class TelemetryState(
        val fps: Float? = null,
        val inferenceMs: Long? = null,
        val objectCount: Int = 0,
        val avgConfidence: Float? = null,
        val sourceWidth: Int = 0,
        val sourceHeight: Int = 0,
        val aiActive: Boolean = false,
    )

    private val _frames = MutableStateFlow<DetectionResult?>(null)
    val frames: StateFlow<DetectionResult?> = _frames.asStateFlow()

    private val _captureStatus = MutableStateFlow(CaptureStatus.STOPPED)
    val captureStatus: StateFlow<CaptureStatus> = _captureStatus.asStateFlow()

    private val _captureDetail = MutableStateFlow("Захват экрана выключен")
    val captureDetail: StateFlow<String> = _captureDetail.asStateFlow()

    private val _modelState = MutableStateFlow(ModelState())
    val modelState: StateFlow<ModelState> = _modelState.asStateFlow()

    private val _telemetry = MutableStateFlow(TelemetryState())
    val telemetry: StateFlow<TelemetryState> = _telemetry.asStateFlow()

    private val _hudBoxesServiceRunning = MutableStateFlow(false)
    val hudBoxesServiceRunning: StateFlow<Boolean> = _hudBoxesServiceRunning.asStateFlow()

    private val _hudPanelRunning = MutableStateFlow(false)
    val hudPanelRunning: StateFlow<Boolean> = _hudPanelRunning.asStateFlow()

    fun publish(result: DetectionResult, measuredFps: Float?) {
        _frames.value = result
        val avgConf = if (result.detections.isNotEmpty()) {
            result.detections.map { it.confidence }.average().toFloat()
        } else null

        _telemetry.value = TelemetryState(
            fps = measuredFps,
            inferenceMs = result.inferenceMs,
            objectCount = result.detections.size,
            avgConfidence = avgConf,
            sourceWidth = result.sourceWidth,
            sourceHeight = result.sourceHeight,
            aiActive = true,
        )
    }

    fun setCaptureStatus(status: CaptureStatus, detail: String) {
        _captureStatus.value = status
        _captureDetail.value = detail
        if (status != CaptureStatus.ACTIVE) {
            clearDetections()
        }
    }

    fun setModelState(state: ModelState) {
        _modelState.value = state
        if (!state.loaded) {
            clearDetections()
        }
    }

    fun setHudBoxesRunning(running: Boolean) {
        _hudBoxesServiceRunning.value = running
    }

    fun setHudPanelRunning(running: Boolean) {
        _hudPanelRunning.value = running
    }

    fun clearDetections() {
        _frames.value = null
        _telemetry.value = TelemetryState(
            fps = null,
            inferenceMs = null,
            objectCount = 0,
            avgConfidence = null,
            sourceWidth = 0,
            sourceHeight = 0,
            aiActive = false,
        )
    }
}
