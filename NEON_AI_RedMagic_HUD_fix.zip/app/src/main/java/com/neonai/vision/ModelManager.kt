package com.neonai.vision

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream

/**
 * Управляет выбором и подключением ONNX-модели для детектора YOLO / NEON AI.
 *
 * Приоритет выбора активной модели:
 * 1. Модель (.onnx), импортированная пользователем во внутреннее хранилище через интерфейс.
 * 2. Встроенная модель из папки assets/ (neon_brawl_model.onnx, best_fp16.onnx, best.onnx, best_int8.onnx).
 * 3. Если модель отсутствует — возвращает null, чтобы пользователь мог выбрать свой файл .onnx.
 */
object ModelManager {

    const val MISSING_MODEL_MESSAGE =
        "ONNX-модель не выбрана: выберите .onnx в меню или используйте встроенную neon_brawl_model.onnx"
    private const val MODELS_DIR = "onnx_models"
    private val CANDIDATE_ASSETS = listOf(
        "neon_brawl_model.onnx",
        "best_fp16.onnx",
        "best.onnx",
        "best_int8.onnx"
    )

    data class ResolvedModel(
        val filePath: String?,
        val assetName: String?,
        val displayName: String,
    ) {
        val isAvailable: Boolean get() = filePath != null || assetName != null
    }

    fun getModelsDir(context: Context): File {
        return File(context.applicationContext.filesDir, MODELS_DIR).apply {
            if (!exists()) mkdirs()
        }
    }

    fun findBundledAsset(context: Context): String? {
        val assets = try {
            context.applicationContext.assets.list("")?.toSet() ?: emptySet()
        } catch (_: Exception) {
            emptySet()
        }
        return CANDIDATE_ASSETS.firstOrNull { it in assets }
    }

    /** Возвращает активную модель: сначала выбранную пользователем во внутреннем хранилище, затем из assets. */
    fun resolveActiveModel(context: Context): ResolvedModel? {
        val appCtx = context.applicationContext
        HudSettings.init(appCtx)
        val cfg = HudSettings.config.value

        val savedPath = cfg.selectedModelPath
        if (!savedPath.isNullOrBlank()) {
            val f = File(savedPath)
            if (f.exists() && f.isFile && f.length() > 0L) {
                val name = cfg.selectedModelName ?: f.name
                return ResolvedModel(
                    filePath = f.absolutePath,
                    assetName = null,
                    displayName = "$name (файл)"
                )
            } else {
                // Файл удалён или повреждён — очищаем устаревшую ссылку
                HudSettings.update(appCtx) {
                    it.copy(selectedModelPath = null, selectedModelName = null)
                }
            }
        }

        val bundled = findBundledAsset(appCtx)
        if (bundled != null) {
            return ResolvedModel(
                filePath = null,
                assetName = bundled,
                displayName = "assets/$bundled (ONNX в проекте)"
            )
        }

        return null
    }

    /** Копирует выбранный через OpenDocument ONNX-файл во внутреннее хранилище и активирует его. */
    fun importModelFromUri(context: Context, uri: Uri): Result<ResolvedModel> {
        val appCtx = context.applicationContext
        return try {
            val originalName = queryDisplayName(appCtx, uri) ?: "custom_model.onnx"
            if (!originalName.lowercase().endsWith(".onnx")) {
                return Result.failure(IllegalArgumentException("Выбранный файл должен иметь расширение .onnx"))
            }

            val safeFileName = originalName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val targetFile = File(getModelsDir(appCtx), safeFileName)

            appCtx.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    val copied = input.copyTo(output)
                    if (copied <= 0L) {
                        targetFile.delete()
                        return Result.failure(IllegalStateException("Файл модели пуст (0 байт)"))
                    }
                }
            } ?: return Result.failure(IllegalStateException("Не удалось открыть поток выбранного файла"))

            // Удаляем старые импортированные модели, чтобы не засорять хранилище
            getModelsDir(appCtx).listFiles()?.forEach { old ->
                if (old.absolutePath != targetFile.absolutePath) {
                    old.delete()
                }
            }

            HudSettings.update(appCtx) {
                it.copy(
                    selectedModelPath = targetFile.absolutePath,
                    selectedModelName = originalName,
                )
            }

            Result.success(
                ResolvedModel(
                    filePath = targetFile.absolutePath,
                    assetName = null,
                    displayName = "$originalName (файл)",
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun clearImportedModel(context: Context) {
        val appCtx = context.applicationContext
        getModelsDir(appCtx).listFiles()?.forEach { it.delete() }
        HudSettings.update(appCtx) {
            it.copy(selectedModelPath = null, selectedModelName = null)
        }
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (_: Exception) {
            uri.lastPathSegment
        }
    }
}
