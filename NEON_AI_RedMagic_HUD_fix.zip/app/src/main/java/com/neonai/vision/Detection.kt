package com.neonai.vision

import android.graphics.RectF

/** Один найденный объект. Координаты [box] — в пикселях исходного захваченного кадра. */
data class Detection(
    val box: RectF,
    val classId: Int,
    val label: String,
    val confidence: Float,
)

/** Результат одного прогона инференса. */
data class DetectionResult(
    val detections: List<Detection>,
    val sourceWidth: Int,
    val sourceHeight: Int,
    val inferenceMs: Long,
    val timestampMs: Long = System.currentTimeMillis(),
)
