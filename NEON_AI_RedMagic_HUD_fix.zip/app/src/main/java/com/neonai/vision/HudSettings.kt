package com.neonai.vision

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Хранилище и реактивный поток настроек NEON AI (SharedPreferences + StateFlow).
 * Содержит параметры инференса ONNX, отображения HUD и автозапуска при старте Brawl Stars.
 */
data class NeonConfig(
    val confThreshold: Float = 0.30f,
    val iouThreshold: Float = 0.45f,
    val targetFps: Int = 15,
    val useNnapi: Boolean = false,
    val showBoxes: Boolean = true,
    val showLabels: Boolean = true,
    val showConfidence: Boolean = true,
    val showDebugCoords: Boolean = false,
    val hudAlpha: Float = 0.92f,
    val hudScale: Float = 1.0f,
    val selectedModelPath: String? = null,
    val selectedModelName: String? = null,
    val autoLaunchOnBrawlStars: Boolean = true,
    val brawlStarsPackageName: String = "com.supercell.brawlstars",
)

object HudSettings {
    private const val PREFS_NAME = "neon_ai_settings"
    private const val KEY_CONF = "conf_threshold"
    private const val KEY_IOU = "iou_threshold"
    private const val KEY_FPS = "target_fps"
    private const val KEY_NNAPI = "use_nnapi"
    private const val KEY_BOXES = "show_boxes"
    private const val KEY_LABELS = "show_labels"
    private const val KEY_CONFIDENCE = "show_confidence"
    private const val KEY_DEBUG_COORDS = "show_debug_coords"
    private const val KEY_HUD_ALPHA = "hud_alpha"
    private const val KEY_HUD_SCALE = "hud_scale"
    private const val KEY_MODEL_PATH = "selected_model_path"
    private const val KEY_MODEL_NAME = "selected_model_name"
    private const val KEY_AUTO_BRAWL = "auto_launch_brawl_stars"
    private const val KEY_BRAWL_PKG = "brawl_stars_package_name"

    private val _config = MutableStateFlow(NeonConfig())
    val config: StateFlow<NeonConfig> = _config.asStateFlow()

    @Volatile
    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            _config.value = NeonConfig(
                confThreshold = prefs.getFloat(KEY_CONF, 0.30f).coerceIn(0.05f, 0.95f),
                iouThreshold = prefs.getFloat(KEY_IOU, 0.45f).coerceIn(0.05f, 0.95f),
                targetFps = prefs.getInt(KEY_FPS, 15).let { if (it in listOf(10, 15, 20, 30)) it else 15 },
                useNnapi = prefs.getBoolean(KEY_NNAPI, false),
                showBoxes = prefs.getBoolean(KEY_BOXES, true),
                showLabels = prefs.getBoolean(KEY_LABELS, true),
                showConfidence = prefs.getBoolean(KEY_CONFIDENCE, true),
                showDebugCoords = prefs.getBoolean(KEY_DEBUG_COORDS, false),
                hudAlpha = prefs.getFloat(KEY_HUD_ALPHA, 0.92f).coerceIn(0.25f, 1.0f),
                hudScale = prefs.getFloat(KEY_HUD_SCALE, 1.0f).coerceIn(0.75f, 1.35f),
                selectedModelPath = prefs.getString(KEY_MODEL_PATH, null),
                selectedModelName = prefs.getString(KEY_MODEL_NAME, null),
                autoLaunchOnBrawlStars = prefs.getBoolean(KEY_AUTO_BRAWL, true),
                brawlStarsPackageName = prefs.getString(KEY_BRAWL_PKG, "com.supercell.brawlstars")
                    ?.takeIf { it.isNotBlank() } ?: "com.supercell.brawlstars",
            )
            initialized = true
        }
    }

    fun update(context: Context, transform: (NeonConfig) -> NeonConfig) {
        init(context)
        val updated = transform(_config.value)
        _config.value = updated
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().apply {
            putFloat(KEY_CONF, updated.confThreshold)
            putFloat(KEY_IOU, updated.iouThreshold)
            putInt(KEY_FPS, updated.targetFps)
            putBoolean(KEY_NNAPI, updated.useNnapi)
            putBoolean(KEY_BOXES, updated.showBoxes)
            putBoolean(KEY_LABELS, updated.showLabels)
            putBoolean(KEY_CONFIDENCE, updated.showConfidence)
            putBoolean(KEY_DEBUG_COORDS, updated.showDebugCoords)
            putFloat(KEY_HUD_ALPHA, updated.hudAlpha)
            putFloat(KEY_HUD_SCALE, updated.hudScale)
            if (updated.selectedModelPath != null) {
                putString(KEY_MODEL_PATH, updated.selectedModelPath)
            } else {
                remove(KEY_MODEL_PATH)
            }
            if (updated.selectedModelName != null) {
                putString(KEY_MODEL_NAME, updated.selectedModelName)
            } else {
                remove(KEY_MODEL_NAME)
            }
            putBoolean(KEY_AUTO_BRAWL, updated.autoLaunchOnBrawlStars)
            putString(KEY_BRAWL_PKG, updated.brawlStarsPackageName)
            apply()
        }
    }
}
