package com.neonai.vision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.neonai.redmagic.MainActivity
import com.neonai.redmagic.OverlayService

/**
 * Фоновый наблюдатель за запуском Brawl Stars (по умолчанию com.supercell.brawlstars).
 * Когда игра выходит на передний план при включённом автозапуске и разрешении Overlay:
 * - автоматически открывает плавающее окно управления и настройки ИИ (OverlayService);
 * - при включённых рамки/боксах запускает прозрачный слой отрисовки (FloatingHudService).
 */
class BrawlWatcherService : Service() {

    private var watcherThread: HandlerThread? = null
    private var watcherHandler: Handler? = null
    private var lastLaunchedForSession = false

    private val pollRunnable = object : Runnable {
        override fun run() {
            try {
                checkForegroundPackage()
            } catch (_: Throwable) {
            }
            watcherHandler?.postDelayed(this, POLL_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        HudSettings.init(this)
        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        watcherThread = HandlerThread("neon-brawl-watcher").apply { start() }
        watcherHandler = Handler(watcherThread!!.looper).apply {
            post(pollRunnable)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun checkForegroundPackage() {
        val cfg = HudSettings.config.value
        if (!cfg.autoLaunchOnBrawlStars) {
            lastLaunchedForSession = false
            return
        }
        if (!Settings.canDrawOverlays(this)) return

        val targetPkg = cfg.brawlStarsPackageName.ifBlank { DEFAULT_BRAWL_PKG }
        val foregroundPkg = detectTopPackageName() ?: return

        if (foregroundPkg == targetPkg) {
            if (!lastLaunchedForSession) {
                lastLaunchedForSession = true
                if (!DetectionHub.hudPanelRunning.value) {
                    ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
                }
                if (cfg.showBoxes && !DetectionHub.hudBoxesServiceRunning.value) {
                    ContextCompat.startForegroundService(this, Intent(this, FloatingHudService::class.java))
                }
            }
        } else {
            lastLaunchedForSession = false
        }
    }

    private fun detectTopPackageName(): String? {
        val usm = getSystemService(USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 5_000L, now) ?: return null
        val event = UsageEvents.Event()
        var topPkg: String? = null

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            ) {
                topPkg = event.packageName
            }
        }
        return topPkg
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, BrawlWatcherService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            301,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this,
            302,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NEON AI • Автозапуск с Brawl Stars")
            .setContentText("Ожидание запуска игры для открытия окна ИИ и HUD")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выключить", stopPending)
            .setOngoing(true)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "NEON AI Brawl Stars Auto-HUD",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        watcherHandler?.removeCallbacks(pollRunnable)
        watcherThread?.quitSafely()
        watcherThread = null
        watcherHandler = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val DEFAULT_BRAWL_PKG = "com.supercell.brawlstars"
        const val ACTION_STOP = "com.neonai.vision.STOP_BRAWL_WATCHER"
        private const val POLL_INTERVAL_MS = 1000L
        private const val NOTIFICATION_ID = 14
        private const val CHANNEL_ID = "neon_brawl_watcher"
    }
}
