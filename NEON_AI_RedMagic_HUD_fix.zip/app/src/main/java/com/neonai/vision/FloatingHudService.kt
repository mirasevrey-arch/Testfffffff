package com.neonai.vision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * Прозрачный полноэкранный слой bounding boxes поверх других приложений.
 * Полностью пропускает касания (FLAG_NOT_TOUCHABLE), чтобы не мешать управлению игрой.
 */
class FloatingHudService : Service() {

    private var windowManager: WindowManager? = null
    private var hudView: HudOverlayView? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate() {
        super.onCreate()
        HudSettings.init(this)
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        createChannel()
        val notification: Notification = NotificationCompatBuilderCompat.build(
            context = this,
            channelId = CHANNEL_ID,
            title = "NEON AI • Bounding Boxes",
            text = "Слой отрисовки детекций активен",
        )

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(13, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(13, notification)
        }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = HudOverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        wm.addView(view, params)
        windowManager = wm
        hudView = view
        DetectionHub.setHudBoxesRunning(true)

        scope.launch {
            combine(
                DetectionHub.frames,
                HudSettings.config,
                DetectionHub.modelState,
            ) { frame, cfg, model ->
                Triple(frame, cfg, model.loaded)
            }.collect { (frame, cfg, loaded) ->
                view.updateState(frame, cfg, loaded)
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "NEON AI Bounding Boxes",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        DetectionHub.setHudBoxesRunning(false)
        scope.cancel()
        hudView?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }
        hudView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "neon_boxes_overlay"
    }
}

internal object NotificationCompatBuilderCompat {
    fun build(
        context: android.content.Context,
        channelId: String,
        title: String,
        text: String,
    ): Notification {
        return androidx.core.app.NotificationCompat.Builder(context, channelId)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }
}
