package com.neonai.vision

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Асинхронный конвейер: Bitmap -> YoloDetector -> DetectionHub.
 * - Выполняет инференс на выделенном фоновом потоке.
 * - Пропускает кадры, если предыдущий кадр ещё обрабатывается или не выдержан интервал targetFps.
 * - Корректно освобождает переданный Bitmap после обработки или при пропуске.
 * - Поддерживает горячее переключение модели и NNAPI без утечек сессий.
 */
class DetectionPipeline(context: Context) {

    private val appContext = context.applicationContext
    private val thread = HandlerThread("neon-yolo-inference").apply { start() }
    private val handler = Handler(thread.looper)

    private val busy = AtomicBoolean(false)
    private val released = AtomicBoolean(false)

    @Volatile
    private var detector: YoloDetector? = null

    @Volatile
    private var loadedSignature: String? = null

    private var lastSubmitElapsedMs = 0L
    private var lastFrameCompletedMs = 0L
    private var smoothedFps: Float? = null

    init {
        HudSettings.init(appContext)
        handler.post { reloadModelIfNeeded(force = true) }
    }

    fun requestModelReload() {
        if (released.get()) return
        handler.post { reloadModelIfNeeded(force = true) }
    }

    private fun reloadModelIfNeeded(force: Boolean = false) {
        if (released.get()) return
        val cfg = HudSettings.config.value
        val resolved = ModelManager.resolveActiveModel(appContext)

        if (resolved == null || !resolved.isAvailable) {
            closeCurrentDetector()
            loadedSignature = null
            smoothedFps = null
            DetectionHub.setModelState(
                DetectionHub.ModelState(
                    loaded = false,
                    modelName = null,
                    runtimeProvider = "—",
                    statusText = ModelManager.MISSING_MODEL_MESSAGE,
                )
            )
            return
        }

        val targetSignature = "${resolved.filePath ?: resolved.assetName}|nnapi=${cfg.useNnapi}"
        if (!force && targetSignature == loadedSignature && detector != null) {
            detector?.confThreshold = cfg.confThreshold
            detector?.iouThreshold = cfg.iouThreshold
            return
        }

        closeCurrentDetector()
        smoothedFps = null

        try {
            val newDetector = YoloDetector(
                context = appContext,
                modelAsset = resolved.assetName,
                modelFilePath = resolved.filePath,
                confThreshold = cfg.confThreshold,
                iouThreshold = cfg.iouThreshold,
                useNnapi = cfg.useNnapi,
            )
            detector = newDetector
            loadedSignature = targetSignature
            DetectionHub.setModelState(
                DetectionHub.ModelState(
                    loaded = true,
                    modelName = resolved.displayName,
                    runtimeProvider = newDetector.executionProvider,
                    statusText = "ГОТОВ (${newDetector.executionProvider})",
                )
            )
        } catch (e: Throwable) {
            detector = null
            loadedSignature = null
            DetectionHub.setModelState(
                DetectionHub.ModelState(
                    loaded = false,
                    modelName = resolved.displayName,
                    runtimeProvider = "ОШИБКА",
                    statusText = "Ошибка загрузки модели: ${e.message ?: "неизвестная ошибка"}",
                )
            )
        }
    }

    private fun closeCurrentDetector() {
        try {
            detector?.close()
        } catch (_: Exception) {
        }
        detector = null
    }

    /**
     * Принимает владение [frame]. Если конвейер занят или превышен targetFps,
     * [frame] немедленно освобождается через recycle() без постановки в очередь.
     */
    fun submit(frame: Bitmap) {
        if (released.get()) {
            if (!frame.isRecycled) frame.recycle()
            return
        }

        val now = SystemClock.elapsedRealtime()
        val targetFps = HudSettings.config.value.targetFps.coerceAtLeast(1)
        val minIntervalMs = 1000L / targetFps

        if (now - lastSubmitElapsedMs < minIntervalMs) {
            if (!frame.isRecycled) frame.recycle()
            return
        }

        if (!busy.compareAndSet(false, true)) {
            if (!frame.isRecycled) frame.recycle()
            return
        }

        lastSubmitElapsedMs = now
        handler.post {
            try {
                if (released.get()) return@post
                reloadModelIfNeeded(force = false)
                val activeDetector = detector ?: return@post

                val cfg = HudSettings.config.value
                activeDetector.confThreshold = cfg.confThreshold
                activeDetector.iouThreshold = cfg.iouThreshold

                val result = try {
                    activeDetector.detect(frame)
                } catch (nnapiErr: IllegalStateException) {
                    // Runtime fallback с NNAPI на CPU при ошибке выполнения
                    if (cfg.useNnapi) {
                        HudSettings.update(appContext) { it.copy(useNnapi = false) }
                        reloadModelIfNeeded(force = true)
                        detector?.detect(frame)
                    } else {
                        throw nnapiErr
                    }
                }

                if (result != null) {
                    val doneAt = SystemClock.elapsedRealtime()
                    if (lastFrameCompletedMs > 0L) {
                        val dt = (doneAt - lastFrameCompletedMs).coerceAtLeast(1L)
                        val instantFps = 1000f / dt.toFloat()
                        smoothedFps = smoothedFps?.let { prev -> prev * 0.7f + instantFps * 0.3f } ?: instantFps
                    }
                    lastFrameCompletedMs = doneAt

                    // Обновляем реальный статус провайдера (например, NNAPI подтверждён после первого запуска)
                    val currentModel = DetectionHub.modelState.value
                    if (currentModel.loaded && currentModel.runtimeProvider != activeDetector.executionProvider) {
                        DetectionHub.setModelState(
                            currentModel.copy(
                                runtimeProvider = activeDetector.executionProvider,
                                statusText = "АКТИВЕН (${activeDetector.executionProvider})",
                            )
                        )
                    }

                    DetectionHub.publish(result, smoothedFps)
                }
            } catch (e: Throwable) {
                DetectionHub.setModelState(
                    DetectionHub.modelState.value.copy(
                        statusText = "Ошибка инференса: ${e.message ?: "сбой runtime"}"
                    )
                )
            } finally {
                if (!frame.isRecycled) {
                    frame.recycle()
                }
                busy.set(false)
            }
        }
    }

    fun release() {
        if (!released.compareAndSet(false, true)) return
        handler.post {
            closeCurrentDetector()
            DetectionHub.clearDetections()
            thread.quitSafely()
        }
    }
}
