"""Создаёт структуру raw/ и dataset/ с кадрами и черновой разметкой YOLO для video_1."""
from pathlib import Path
import json, shutil
import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
raw_img = ROOT / "raw" / "images"
raw_lbl = ROOT / "raw" / "labels"
raw_img.mkdir(parents=True, exist_ok=True)
raw_lbl.mkdir(parents=True, exist_ok=True)

video_candidates = list(ROOT.glob("*.mp4"))
if not video_candidates:
    raise SystemExit("Положи исходное видео (.mp4) в корень проекта и запусти скрипт снова.")

video_path = video_candidates[0]
cap = cv2.VideoCapture(str(video_path))
fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
step = max(1, int(round(fps * 1.0)))
match_id = video_path.stem

idx = saved = 0
prev = None
files = []
while True:
    ok, frame = cap.read()
    if not ok:
        break
    if idx % step == 0:
        small = cv2.cvtColor(cv2.resize(frame, (96, 54)), cv2.COLOR_BGR2GRAY).astype(np.float32)
        diff = 999.0 if prev is None else float(np.mean(np.abs(small - prev)))
        if diff >= 3.0:
            fname = f"{match_id}__{idx:05d}.jpg"
            cv2.imwrite(str(raw_img / fname), frame, [int(cv2.IMWRITE_JPEG_QUALITY), 92])
            files.append(fname)
            prev = small
            saved += 1
    idx += 1
cap.release()

for fname in files:
    im = cv2.imread(str(raw_img / fname))
    ih, iw = im.shape[:2]
    hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)
    boxes = []
    cyan_mask = cv2.inRange(hsv, (82, 90, 90), (105, 255, 255))
    pink_mask = cv2.inRange(hsv, (145, 90, 90), (178, 255, 255))

    sub_cyan = cyan_mask[int(ih * 0.65):int(ih * 0.95), int(iw * 0.50):int(iw * 0.95)]
    cnts_c, _ = cv2.findContours(sub_cyan, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if cnts_c:
        best = max(cnts_c, key=cv2.contourArea)
        if cv2.contourArea(best) > 120:
            x, y, bw, bh = cv2.boundingRect(best)
            cx = (int(iw * 0.50) + x + bw / 2.0) / iw
            cy = (int(ih * 0.65) + y + bh / 2.0) / ih
            boxes.append(f"7 {cx:.6f} {cy:.6f} {max(0.03, min(0.18, bw/iw)):.6f} {max(0.03, min(0.18, bh/ih)):.6f}")

    center_pink = pink_mask[int(ih * 0.15):int(ih * 0.75), int(iw * 0.25):int(iw * 0.75)]
    cnts_p, _ = cv2.findContours(center_pink, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if cnts_p:
        best_p = max(cnts_p, key=cv2.contourArea)
        if cv2.contourArea(best_p) > 250:
            x, y, bw, bh = cv2.boundingRect(best_p)
            cx = (int(iw * 0.25) + x + bw / 2.0) / iw
            cy = (int(ih * 0.15) + y + bh / 2.0) / ih
            boxes.append(f"0 {cx:.6f} {cy:.6f} {max(0.04, min(0.22, bw/iw)):.6f} {max(0.04, min(0.22, bh/ih)):.6f}")

    boxes.append("4 0.500000 0.420000 0.140000 0.080000")
    (raw_lbl / (Path(fname).stem + ".txt")).write_text("\n".join(boxes) + "\n", encoding="utf-8")

for sp in ("train", "val", "test"):
    (ROOT / "dataset" / "images" / sp).mkdir(parents=True, exist_ok=True)
    (ROOT / "dataset" / "labels" / sp).mkdir(parents=True, exist_ok=True)

n = len(files)
n_train = max(1, int(round(n * 0.70)))
n_val = max(1, int(round(n * 0.15)))
for i, fname in enumerate(sorted(files)):
    sp = "train" if i < n_train else ("val" if i < n_train + n_val else "test")
    shutil.copy2(raw_img / fname, ROOT / "dataset" / "images" / sp / fname)
    lbl = Path(fname).stem + ".txt"
    shutil.copy2(raw_lbl / lbl, ROOT / "dataset" / "labels" / sp / lbl)

print(f"Готово: извлечено {saved} кадров, train/val/test подготовлены в {ROOT / 'dataset'}")
