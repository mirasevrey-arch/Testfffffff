"""Экспорт обученных весов в ONNX (FP32 -> FP16 -> опционально INT8).

  python export.py                                   # weights/best.pt -> export/best.onnx + best_fp16.onnx
  python export.py --int8 --calib-dir dataset/images/train   # + best_int8.onnx

Файлы в export/ появляются ТОЛЬКО из реально обученных весов. Без weights/best.pt скрипт остановится.

Формат выхода (без NMS внутри модели): [1, 4+nc, 8400] = cx, cy, w, h (в пикселях 640×640) + score по каждому классу.
FP16: веса переведены в float16, но вход/выход остаются float32 (keep_io_types) — Kotlin-код не меняется.
INT8: статическая QDQ-квантизация по калибровочным кадрам; ОБЯЗАТЕЛЬНО перепроверьте качество через val.py.
"""
import argparse
import shutil
from pathlib import Path

import cv2
import numpy as np
import onnx
import onnxruntime as ort
from ultralytics import YOLO

from common import IMG_EXT, ROOT, to_tensor


def sanity_check(path: Path, imgsz: int):
    sess = ort.InferenceSession(str(path), providers=["CPUExecutionProvider"])
    inp = sess.get_inputs()[0]
    out = sess.run(None, {inp.name: np.random.rand(1, 3, imgsz, imgsz).astype(np.float32)})[0]
    print(f"  {path.name}: вход {inp.name}{inp.shape} {inp.type}, выход {out.shape} — загружается и выполняется")


def convert_fp16(src: Path, dst: Path):
    from onnxconverter_common import float16
    model = onnx.load(str(src))
    model = float16.convert_float_to_float16(model, keep_io_types=True)
    onnx.save(model, str(dst))


class CalibReader:
    def __init__(self, folder: Path, input_name: str, imgsz: int, limit: int):
        files = sorted(p for p in folder.rglob("*") if p.suffix.lower() in IMG_EXT)
        step = max(1, len(files) // limit)
        self.files = files[::step][:limit]
        self.name, self.imgsz, self.it = input_name, imgsz, None
        if not self.files:
            raise SystemExit(f"Нет изображений для калибровки в {folder}")

    def get_next(self):
        if self.it is None:
            self.it = iter(self.files)
        for f in self.it:
            img = cv2.imread(str(f))
            if img is not None:
                return {self.name: to_tensor(img, self.imgsz)}
        return None


def convert_int8(src: Path, dst: Path, calib_dir: Path, imgsz: int, n: int):
    from onnxruntime.quantization import QuantFormat, QuantType, quantize_static
    try:
        from onnxruntime.quantization.shape_inference import quant_pre_process
        pre = dst.with_name("_pre.onnx")
        quant_pre_process(str(src), str(pre), skip_symbolic_shape=True)
        src = pre
    except Exception as e:  # предобработка необязательна
        print(f"  (пропущена предобработка квантизации: {e})")
    name = ort.InferenceSession(str(src), providers=["CPUExecutionProvider"]).get_inputs()[0].name
    quantize_static(str(src), str(dst), CalibReader(calib_dir, name, imgsz, n),
                    quant_format=QuantFormat.QDQ, activation_type=QuantType.QUInt8,
                    weight_type=QuantType.QInt8, per_channel=True)
    pre = dst.with_name("_pre.onnx")
    pre.unlink(missing_ok=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", default=str(ROOT / "weights" / "best.pt"))
    ap.add_argument("--out", default=str(ROOT / "export"))
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--opset", type=int, default=17)
    ap.add_argument("--no-fp16", action="store_true")
    ap.add_argument("--int8", action="store_true")
    ap.add_argument("--calib-dir", default=str(ROOT / "dataset" / "images" / "train"))
    ap.add_argument("--calib-n", type=int, default=200)
    args = ap.parse_args()

    w = Path(args.weights)
    if not w.exists():
        raise SystemExit(f"Нет {w}. Модель не обучена — экспортировать нечего. Сначала: python train.py")
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    tmp = YOLO(str(w)).export(format="onnx", imgsz=args.imgsz, opset=args.opset, simplify=True,
                              dynamic=False, half=False, nms=False, batch=1)
    fp32 = out / "best.onnx"
    shutil.copy2(tmp, fp32)
    shutil.copy2(ROOT / "labels.txt", out / "labels.txt")
    print("\nЭкспорт:")
    sanity_check(fp32, args.imgsz)

    if not args.no_fp16:
        fp16 = out / "best_fp16.onnx"
        convert_fp16(fp32, fp16)
        sanity_check(fp16, args.imgsz)
    if args.int8:
        i8 = out / "best_int8.onnx"
        convert_int8(fp32, i8, Path(args.calib_dir), args.imgsz, args.calib_n)
        sanity_check(i8, args.imgsz)

    print(f"\nФайлы в {out}. Проверьте качество КАЖДОГО варианта: python val.py --weights export/<файл>.onnx --split test")
    print("Скорость FP16/INT8 на телефоне зависит от execution provider — измеряйте на устройстве.")


if __name__ == "__main__":
    main()
