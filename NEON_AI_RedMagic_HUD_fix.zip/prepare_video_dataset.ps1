# Локальная нарезка и проверка датасета для NEON_AI_RedMagic
param(
    [string]$VideoPath = ".\video_1.mp4",
    [string]$MatchId = "video_1",
    [double]$EverySec = 1.0
)

python extract_frames.py $VideoPath --match-id $MatchId --every-sec $EverySec
python prepare_dataset.py
