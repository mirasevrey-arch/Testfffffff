# Статус интеграции NEON AI (REDMAGIC 11 Pro / Android 16)

- **ScreenCaptureService**: реализован полный цикл захвата через `MediaProjection` + `ImageReader` + `VirtualDisplay`, регистрация `MediaProjection.Callback` до создания `VirtualDisplay`, обработка `rowStride`/`pixelStride`, обрезка padding, освобождение `Image` в `finally`, остановка из UI и уведомления.
- **DetectionPipeline & YoloDetector**: подключён реальный инференс ONNX Runtime на фоновом потоке, letterbox 640×640, декодирование `[1, 4+nc, 8400]` / `[1, 8400, 4+nc]`, классовый NMS, динамические `confThreshold`, `iouThreshold`, `targetFps` и переключатель `NNAPI` с откатом на `CPU`.
- **ModelManager**: реализован импорт `.onnx` через `ActivityResultContracts.OpenDocument`, сохранение во внутреннее хранилище и восстановление после перезапуска. Веса модели в архив не вшиты (создаются пользователем через `train_colab.ipynb` или `train.py` + `export.py`).
- **DetectionHub & Floating HUD**: подключён `StateFlow` для реальных детекций, телеметрии и статусов; `OverlayService` и `FloatingHudService` отрисовывают реальные bounding boxes, классы, проценты и панель телеметрии со сворачиванием.
- **Сборка**: добавлен `.github/workflows/build.yml` для сборки Debug APK в GitHub Actions. В текущей среде отсутствуют `gradle`, Android SDK и JDK, поэтому компиляция APK и запуск на устройстве здесь не выполнялись.
