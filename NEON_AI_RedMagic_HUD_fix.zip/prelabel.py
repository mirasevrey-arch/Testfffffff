#!/usr/bin/env python3
"""
Генерация черновой разметки в формате YOLO TXT с помощью предобученной или кастомной модели Ultralytics.

ВАЖНО:
- Скрипт НЕ создаёт пустые или искусственные аннотации для объектов, которые модель не обнаружила.
- Файл .txt создаётся только если на изображении найден хотя бы один объект с уверенностью >= --conf.
- Любую черновую разметку НЕОБХОДИМО проверить и исправить вручную в CVAT / Label Studio / Roboflow,
  так как стандартные веса COCO не совпадают с 8 игровыми классами из labels.txt.
"""
import argparse
from pathlib import Path
from ultralytics import YOLO

IMG_EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.webp'}


def iter_images(source: Path):
    if source.is_file():
        if source.suffix.lower() in IMG_EXTS:
            yield source
        else:
            raise SystemExit(f"Неподдерживаемый формат файла: {source}")
    elif source.is_dir():
        for p in sorted(source.rglob('*')):
            if p.is_file() and p.suffix.lower() in IMG_EXTS:
                yield p
    else:
        raise SystemExit(f"Путь не найден: {source}")


def main():
    parser = argparse.ArgumentParser(description="Черновая авторазметка изображений в формат YOLO TXT")
    parser.add_argument('--model', default='yolo11s.pt', help='Путь к весам модели Ultralytics (.pt)')
    parser.add_argument('--images', required=True, help='Путь к одному изображению или каталогу с изображениями')
    parser.add_argument('--out', required=True, help='Каталог для сохранения файлов .txt')
    parser.add_argument('--conf', type=float, default=0.25, help='Порог confidence (по умолчанию 0.25)')
    parser.add_argument('--iou', type=float, default=0.45, help='Порог IoU для NMS (по умолчанию 0.45)')
    args = parser.parse_args()

    source_path = Path(args.images)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    images = list(iter_images(source_path))
    if not images:
        raise SystemExit(f"Изображения не найдены по пути: {source_path}")

    model = YOLO(args.model)
    processed = 0
    files_with_objects = 0
    total_boxes = 0

    for img_path in images:
        result = model.predict(str(img_path), conf=args.conf, iou=args.iou, verbose=False)[0]
        processed += 1
        if result.boxes is None or len(result.boxes) == 0:
            continue

        h, w = result.orig_shape[0], result.orig_shape[1]
        lines = []
        for box in result.boxes:
            cls_id = int(box.cls.item())
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            cx = max(0.0, min(1.0, ((x1 + x2) / 2.0) / w))
            cy = max(0.0, min(1.0, ((y1 + y2) / 2.0) / h))
            bw = max(0.0, min(1.0, (x2 - x1) / w))
            bh = max(0.0, min(1.0, (y2 - y1) / h))
            if bw <= 0.0 or bh <= 0.0:
                continue
            lines.append(f"{cls_id} {cx:.6f} {cy:.6f} {bw:.6f} {bh:.6f}")

        if lines:
            out_file = out_dir / f"{img_path.stem}.txt"
            out_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
            files_with_objects += 1
            total_boxes += len(lines)

    print(f"Обработано изображений: {processed}")
    print(f"Создано файлов разметки (с найденными объектами): {files_with_objects}, всего рамок: {total_boxes}")
    print(f"Каталог результатов: {out_dir.resolve()}")
    print("ВНИМАНИЕ: Черновую разметку обязательно нужно проверить вручную перед обучением модели!")


if __name__ == '__main__':
    main()
