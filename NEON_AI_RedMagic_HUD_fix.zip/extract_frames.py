"""Нарезка кадров из записи экрана (mp4) для последующей разметки.

Имена файлов: <match_id>__<номер кадра>.jpg — prepare_dataset.py делит выборки
по match_id, чтобы кадры одного матча не попадали одновременно в train и val.

Пример:
  python extract_frames.py rec_001.mp4 --match-id m001 --every-sec 0.7
"""
import argparse
from pathlib import Path

import cv2
import numpy as np

from common import ROOT


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--out", default=str(ROOT / "raw" / "images"))
    ap.add_argument("--match-id", default=None, help="по умолчанию — имя файла видео")
    ap.add_argument("--every-sec", type=float, default=1.0)
    ap.add_argument("--min-diff", type=float, default=3.0,
                    help="пропускать кадры, почти не отличающиеся от предыдущего сохранённого (0 — выключить)")
    args = ap.parse_args()

    cap = cv2.VideoCapture(args.video)
    if not cap.isOpened():
        raise SystemExit(f"Не удалось открыть видео: {args.video}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    step = max(1, int(round(fps * args.every_sec)))
    match_id = args.match_id or Path(args.video).stem
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    idx = saved = 0
    prev = None
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % step == 0:
            small = cv2.cvtColor(cv2.resize(frame, (96, 54)), cv2.COLOR_BGR2GRAY).astype(np.float32)
            if prev is None or args.min_diff <= 0 or float(np.abs(small - prev).mean()) >= args.min_diff:
                cv2.imwrite(str(out / f"{match_id}__{idx:07d}.jpg"), frame, [cv2.IMWRITE_JPEG_QUALITY, 95])
                prev = small
                saved += 1
        idx += 1
    cap.release()
    print(f"Прочитано кадров: {idx}, сохранено: {saved} -> {out}")


if __name__ == "__main__":
    main()
