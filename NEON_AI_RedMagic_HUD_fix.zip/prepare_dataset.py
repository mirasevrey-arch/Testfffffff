"""Проверка разметки и разбиение на train/val/test.

Вход:  raw/images/*.jpg  +  raw/labels/*.txt  (YOLO-формат: class cx cy w h, нормализованные 0..1)
Выход: dataset/images/{train,val,test}, dataset/labels/{train,val,test}, dataset/stats.json

Разбиение идёт ПО ГРУППАМ: группа = часть имени файла до "__" (match_id).
Так соседние кадры одного матча не утекают из train в val и не завышают метрики.
Если "__" в именах нет, каждое изображение — своя группа (возможна утечка, будет предупреждение).
"""
import argparse
import json
import random
import shutil
from collections import Counter, defaultdict
from pathlib import Path

from common import IMG_EXT, ROOT, load_data_cfg


def validate_label(path: Path, nc: int):
    errors, counts = [], Counter()
    for n, line in enumerate(path.read_text().splitlines(), 1):
        if not line.strip():
            continue
        parts = line.split()
        if len(parts) != 5:
            errors.append(f"{path.name}:{n}: ожидалось 5 значений (bbox), получено {len(parts)}")
            continue
        try:
            c = int(parts[0])
            cx, cy, w, h = map(float, parts[1:])
        except ValueError:
            errors.append(f"{path.name}:{n}: нечисловые значения")
            continue
        if not 0 <= c < nc:
            errors.append(f"{path.name}:{n}: class id {c} вне диапазона 0..{nc - 1}")
        elif not all(0.0 <= v <= 1.0 for v in (cx, cy, w, h)) or w <= 0 or h <= 0:
            errors.append(f"{path.name}:{n}: координаты вне 0..1 или нулевой размер")
        else:
            counts[c] += 1
    return errors, counts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", default=str(ROOT / "raw" / "images"))
    ap.add_argument("--labels", default=str(ROOT / "raw" / "labels"))
    ap.add_argument("--data", default="data.yaml")
    ap.add_argument("--val", type=float, default=0.15)
    ap.add_argument("--test", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--allow-empty", action="store_true",
                    help="изображения без .txt считать фоном (пустая разметка); иначе они пропускаются")
    ap.add_argument("--clean", action="store_true", help="очистить dataset/images и dataset/labels перед копированием")
    args = ap.parse_args()

    _, cfg = load_data_cfg(args.data)
    nc, names = cfg["nc"], cfg["names"]
    out = Path(cfg["path"])

    imgs = sorted(p for p in Path(args.images).iterdir() if p.suffix.lower() in IMG_EXT)
    if not imgs:
        raise SystemExit(f"В {args.images} нет изображений. Сначала соберите и разметьте данные (см. docs/LABELING_GUIDE.md).")

    items, bad, skipped = [], [], 0
    for img in imgs:
        lab = Path(args.labels) / (img.stem + ".txt")
        if not lab.exists():
            if args.allow_empty:
                items.append((img, None, Counter()))
            else:
                skipped += 1
            continue
        errs, cnt = validate_label(lab, nc)
        if errs:
            bad.extend(errs)
        else:
            items.append((img, lab, cnt))

    if bad:
        print("ОШИБКИ В РАЗМЕТКЕ (эти файлы исключены):")
        for e in bad[:50]:
            print("  ", e)
        if len(bad) > 50:
            print(f"   ... и ещё {len(bad) - 50}")
    if skipped:
        print(f"Пропущено изображений без файла разметки: {skipped} (используйте --allow-empty для фоновых кадров)")
    if not items:
        raise SystemExit("Нет валидных размеченных изображений.")

    groups = defaultdict(list)
    for it in items:
        stem = it[0].stem
        groups[stem.split("__")[0] if "__" in stem else stem].append(it)
    if all("__" not in it[0].stem for it in items):
        print("ВНИМАНИЕ: имена без 'match_id__' — разбиение случайное, возможна утечка данных между train и val.")

    keys = sorted(groups)
    random.Random(args.seed).shuffle(keys)
    total = len(items)
    target = {"test": int(total * args.test), "val": int(total * args.val)}
    split_items = {"train": [], "val": [], "test": []}
    for k in keys:
        if len(split_items["test"]) < target["test"]:
            split_items["test"].extend(groups[k])
        elif len(split_items["val"]) < target["val"]:
            split_items["val"].extend(groups[k])
        else:
            split_items["train"].extend(groups[k])
    if not split_items["train"]:
        raise SystemExit("Train-выборка пуста: данных слишком мало для такого разбиения.")

    if args.clean:
        for sub in ("images", "labels"):
            shutil.rmtree(out / sub, ignore_errors=True)

    stats = {}
    for split, lst in split_items.items():
        (out / "images" / split).mkdir(parents=True, exist_ok=True)
        (out / "labels" / split).mkdir(parents=True, exist_ok=True)
        counts = Counter()
        for img, lab, cnt in lst:
            shutil.copy2(img, out / "images" / split / img.name)
            dst = out / "labels" / split / (img.stem + ".txt")
            if lab is None:
                dst.write_text("")
            else:
                shutil.copy2(lab, dst)
            counts.update(cnt)
        stats[split] = {"images": len(lst), "instances": {names[c]: counts.get(c, 0) for c in range(nc)}}

    (out / "stats.json").write_text(json.dumps(stats, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\nДатасет: {out}")
    for split, s in stats.items():
        print(f"  {split:5s}: {s['images']} изображений")
    print("\nЭкземпляры по классам (train / val / test):")
    for c in range(nc):
        n = names[c]
        a, b, t = (stats[s]["instances"][n] for s in ("train", "val", "test"))
        flag = "  <-- НЕТ В VAL, метрика по классу будет недоступна" if b == 0 else (
            "  <-- мало примеров" if a < 300 else "")
        print(f"  {c} {n:16s} {a:6d} / {b:5d} / {t:5d}{flag}")


if __name__ == "__main__":
    main()
