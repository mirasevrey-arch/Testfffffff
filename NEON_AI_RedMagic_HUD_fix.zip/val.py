"""Проверка качества: mAP, precision, recall по классам.

  python val.py --weights weights/best.pt --split val
  python val.py --weights export/best.onnx --split test    # проверка именно ONNX-файла
Метрики считаются только по реальной выборке; отчёт пишется в runs/val_report_<split>.json.
"""
import argparse
import json

from ultralytics import YOLO

from common import ROOT, count_images, load_data_cfg
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", default=str(ROOT / "weights" / "best.pt"))
    ap.add_argument("--data", default="data.yaml")
    ap.add_argument("--split", default="val", choices=["train", "val", "test"])
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--device", default=None)
    args = ap.parse_args()

    if not Path(args.weights).exists():
        raise SystemExit(f"Нет файла {args.weights}. Сначала обучите модель: python train.py")
    data_yaml, cfg = load_data_cfg(args.data)
    if count_images(Path(cfg["path"]) / "images" / args.split) == 0:
        raise SystemExit(f"Выборка '{args.split}' пуста.")

    model = YOLO(args.weights)
    m = model.val(data=data_yaml, split=args.split, imgsz=args.imgsz, conf=0.001, iou=0.6,
                  device=args.device, plots=True, project=str(ROOT / "runs"), name=f"val_{args.split}")

    names = cfg["names"]
    report = {"weights": args.weights, "split": args.split,
              "mAP50": float(m.box.map50), "mAP50-95": float(m.box.map),
              "precision": float(m.box.mp), "recall": float(m.box.mr), "per_class": {}}
    print(f"\n{'класс':16s} {'P':>6s} {'R':>6s} {'AP50':>6s} {'AP50-95':>8s}")
    for i, c in enumerate(m.box.ap_class_index):
        p, r, ap50, ap = m.box.class_result(i)
        report["per_class"][names[int(c)]] = {"P": float(p), "R": float(r), "AP50": float(ap50), "AP50-95": float(ap)}
        print(f"{names[int(c)]:16s} {p:6.3f} {r:6.3f} {ap50:6.3f} {ap:8.3f}")
    missing = [names[i] for i in range(cfg['nc']) if i not in set(int(x) for x in m.box.ap_class_index)]
    if missing:
        print(f"\nКлассы без примеров в выборке (метрики нет): {', '.join(missing)}")
    print(f"\nВсего: mAP50={report['mAP50']:.3f}  mAP50-95={report['mAP50-95']:.3f}")

    out = ROOT / "runs" / f"val_report_{args.split}.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Отчёт: {out}")


if __name__ == "__main__":
    main()
