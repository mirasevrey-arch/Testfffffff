"""Обучение YOLO-модели NEON-YOLO (Ultralytics).

Примеры:
  python train.py                                   # дообучение yolo11s.pt, 150 эпох
  python train.py --model yolo11n.pt --epochs 200   # nano-вариант (быстрее на телефоне)
  python train.py --scratch --epochs 300            # с нуля по models/neon_yolo11s.yaml (нужно много данных)
  python train.py --resume runs/neon/weights/last.pt
"""
import argparse
import shutil
import sys
from pathlib import Path

from ultralytics import YOLO

from common import ROOT, count_images, load_data_cfg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data.yaml")
    ap.add_argument("--model", default="yolo11s.pt", help="предобученные веса Ultralytics (скачиваются при первом запуске)")
    ap.add_argument("--arch", default=str(ROOT / "models" / "neon_yolo11s.yaml"), help="yaml архитектуры для --scratch")
    ap.add_argument("--scratch", action="store_true", help="обучение с нуля, без предобученных весов")
    ap.add_argument("--epochs", type=int, default=150)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--batch", type=int, default=16, help="-1 = автоподбор")
    ap.add_argument("--device", default=None, help="0, 0,1 или cpu")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--patience", type=int, default=50)
    ap.add_argument("--name", default="neon")
    ap.add_argument("--resume", default=None, help="путь к last.pt для продолжения")
    ap.add_argument("--min-train-images", type=int, default=200)
    ap.add_argument("--force", action="store_true", help="не останавливаться при малом датасете")
    args = ap.parse_args()

    if args.resume:
        YOLO(args.resume).train(resume=True)
        return

    data_yaml, cfg = load_data_cfg(args.data)
    root = Path(cfg["path"])
    n_train, n_val = count_images(root / "images" / "train"), count_images(root / "images" / "val")
    if n_train == 0 or n_val == 0:
        sys.exit("Датасет пуст. Соберите и разметьте скриншоты (docs/LABELING_GUIDE.md), "
                 "затем выполните: python prepare_dataset.py")
    if n_train < args.min_train_images and not args.force:
        sys.exit(f"В train только {n_train} изображений (< {args.min_train_images}). Этого недостаточно для "
                 "осмысленного результата. Добавьте данные или запустите с --force для пробного прогона.")
    print(f"train={n_train}, val={n_val}")

    model = YOLO(args.arch if args.scratch else args.model)
    model.train(
        data=data_yaml,
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        device=args.device,
        workers=args.workers,
        patience=args.patience,
        project=str(ROOT / "runs"),
        name=args.name,
        exist_ok=False,
        cos_lr=True,
        close_mosaic=10,
        # Аугментации, подходящие для игровых скриншотов:
        mosaic=1.0, scale=0.5, translate=0.1, fliplr=0.5, flipud=0.0, degrees=0.0,
        hsv_h=0.015, hsv_s=0.5, hsv_v=0.35,
        plots=True,
    )

    best = Path(model.trainer.best)
    (ROOT / "weights").mkdir(exist_ok=True)
    shutil.copy2(best, ROOT / "weights" / "best.pt")
    print(f"\nГотово. Лучшие веса: {best}\nКопия: weights/best.pt\n"
          "Далее: python val.py --split val  ->  python export.py")


if __name__ == "__main__":
    main()
