"""Общие утилиты проекта."""
from pathlib import Path

import cv2
import numpy as np
import yaml

ROOT = Path(__file__).resolve().parent
IMG_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}


def load_data_cfg(data: str = "data.yaml"):
    """Возвращает (путь к yaml с абсолютным path, словарь конфигурации)."""
    data_path = Path(data)
    if not data_path.is_absolute():
        data_path = ROOT / data_path
    cfg = yaml.safe_load(data_path.read_text(encoding="utf-8"))
    ds = Path(cfg.get("path", "dataset"))
    if not ds.is_absolute():
        ds = (data_path.parent / ds).resolve()
    cfg["path"] = str(ds)
    out = ROOT / "runs" / "_resolved_data.yaml"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False), encoding="utf-8")
    return str(out), cfg


def count_images(folder: Path) -> int:
    if not folder.exists():
        return 0
    return sum(1 for p in folder.iterdir() if p.suffix.lower() in IMG_EXT)


def letterbox(img_bgr: np.ndarray, size: int = 640, color: int = 114):
    """Letterbox с центрированием. Должен совпадать с YoloDetector.kt.

    Возвращает (изображение size×size, scale, pad_x, pad_y).
    """
    h, w = img_bgr.shape[:2]
    scale = min(size / w, size / h)
    new_w, new_h = int(round(w * scale)), int(round(h * scale))
    resized = cv2.resize(img_bgr, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
    pad_x, pad_y = (size - new_w) // 2, (size - new_h) // 2
    canvas = np.full((size, size, 3), color, dtype=np.uint8)
    canvas[pad_y:pad_y + new_h, pad_x:pad_x + new_w] = resized
    return canvas, scale, pad_x, pad_y


def to_tensor(img_bgr: np.ndarray, size: int = 640) -> np.ndarray:
    """BGR изображение -> float32 NCHW [1,3,size,size], RGB, 0..1."""
    boxed, *_ = letterbox(img_bgr, size)
    rgb = cv2.cvtColor(boxed, cv2.COLOR_BGR2RGB)
    return (rgb.transpose(2, 0, 1)[None].astype(np.float32)) / 255.0
